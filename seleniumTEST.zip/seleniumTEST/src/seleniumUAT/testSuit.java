package seleniumUAT;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import automation.ICDeveloper;
import automation.ICDeveloper2;
import automation.ICDeveloper3;
import automation.ICDeveloper4;
import automation.PhoneControlIP8815E;
import automation.chrometerminal;

public class testSuit extends testSetup {
	private static errorReason errReason = new errorReason();
	//private static errorReason errReason = new errorReason();
	//public interface getSystemConf();
	public static List testcase = new ArrayList();
	private static resultJiraReport jiraReport = new resultJiraReport();


	
	public void suit() throws InterruptedException {
	    String testID = null;
		String retString = null;
		boolean result = false;	
		String ts = null;
		//tcLogin 				tc0001 = new tcLogin("tc-0001");
		//getSysConf.getConf();		
		
		tcSystemTotalStat			SystemTotalStat 			= new tcSystemTotalStat(); //tc-0100
		tcIEStatTenant				IEStatTenant				= new tcIEStatTenant(); //tc-0200
		tcIEStatExtensionLine			IEStatExtensionLine 			= new tcIEStatExtensionLine(); //tc-0300
		tcIEStatEndPoint			IEStatEndPoint 				= new tcIEStatEndPoint(); //tc-0400
		tcIEStatSIPTrunk			IEStatSIPTrunk 				= new tcIEStatSIPTrunk(); //tc-0500
		tcIEStatACD				IEStatACD 				= new tcIEStatACD(); //tc-0600
		tcCTIStatTotalInbound			CTIStatTotalInbound 			= new tcCTIStatTotalInbound(); //tc-0700
		tcCTIStatRealInbound			CTIStatRealInbound			= new tcCTIStatRealInbound(); //tc-0800
		tcCTIStatQueueStandby			CTIStatQueueStandby 			= new tcCTIStatQueueStandby();	//tc0900
		tcCTIStatQueueAbandon			CTIStatQueueAbandon 			= new tcCTIStatQueueAbandon();	//tc1000
		tcCTIStatSkillSet			CTIStatSkillSet 			= new tcCTIStatSkillSet();		//tc1100
		tcCTIStatOtherQueueCenter		TIStatOtherQueueCenter 			= new tcCTIStatOtherQueueCenter(); //tc1200
		tcCTIStatAnsRatioSL			CTIStatAnsRatioSL 			= new tcCTIStatAnsRatioSL();		//tc1300
		tcCounselorGroup			CounselorGroup	 			= new tcCounselorGroup();		//tc1400
		tcCounselorCallProcess			CounselorCallProcess 			= new tcCounselorCallProcess(); //tc1500
		tcCounselorStatus			CounselorStatus	 			= new tcCounselorStatus();		//tc1600
		tcCounselorQueueSkill			CounselorQueueSkill 			= new tcCounselorQueueSkill(); //tc1700
		tcCounselorRestReason			CounselorRestReason	 		= new tcCounselorRestReason(); //tc1800
			//tcOMNIStatTotalInbound		tc1900 = new tcOMNIStatTotalInbound("tc-1908"); // 誘멸뎄�쁽
		tcResourceCompany			ResourceCompany				= new tcResourceCompany(); //tc6000
		tcResourceTenant			ResourceTenant	 			= new tcResourceTenant(); //tc2000
		tcResourceOutSourcing			ResourceOutSourcing 			= new tcResourceOutSourcing(); //tc2100
		tcResourceCenterManage			ResourceCenterManage 			= new tcResourceCenterManage(); //tc2200
		tcResourceNodeManage			ResourceNodeManage 			= new tcResourceNodeManage(); //tc2300
		tcResourceTenantbyNode			ResourceTenantbyNode 			= new tcResourceTenantbyNode();
		tcResourceTotalLicense			ResourceTotalLicense 			= new tcResourceTotalLicense(); //tc-5000
		tcSystemInformationManage		SystemInformationManage 		= new tcSystemInformationManage(); //tc-2500
		tcResourceUserManage			ResourceUserManage 			= new tcResourceUserManage(); //tc-2600
		tcOrganizeEndPoint			OrganizeEndPoint 			= new tcOrganizeEndPoint(); //tc-2700
		tcOrganizeOutRouting			OrganizeOutRouting 			= new tcOrganizeOutRouting(); //tc-2800
		tcOrganizePreNumberConversion		OrganizePreNumberConversion 		= new tcOrganizePreNumberConversion(); //tc-2900
		tcOrganizeDIDDNISManage			OrganizeDIDDNISManage 			= new tcOrganizeDIDDNISManage(); // tc-3000
		tcOrganizeDIDANIExchange		OrganizeDIDANIExchange 			= new tcOrganizeDIDANIExchange(); // tc-3100
		tcOrganizeDIDDenyNumberManage		OrganizeDIDDenyNumberManage 		= new tcOrganizeDIDDenyNumberManage(); //tc-3200
		tcOrganizeDODNumberManage		OrganizeDODNumberManage 		= new tcOrganizeDODNumberManage(); //tc-3300
		tcOrganizeSpecialCodeManage	OrganizeSpecialCodeManage = new tcOrganizeSpecialCodeManage(); //tc-4200
		
		tcOrganizeSwitchMentFileManage		OrganizeSwitchMentFileManage 		= new tcOrganizeSwitchMentFileManage(); //tc-3400
		// 以묐났 �궘�젣 �븘�슂. tcOrganizeIPAccessControl		OrganizeIPAccessControl 		= new tcOrganizeIPAccessControl(); // tc-3500
		tcOrganizeOutboundControlGroup		OrganizeOutboundControlGroup 		= new tcOrganizeOutboundControlGroup(); // tc-3600
		tcOrganizeCOSConfig			OrganizeCOSConfig 			= new tcOrganizeCOSConfig(); //tc-3700
		tcOrganizeManageIPTOrganizationChart	OrganizeManageIPTOrganizationChart 	= new tcOrganizeManageIPTOrganizationChart(); // tc-3800
		tcOrganizeManageIPTUsers		OrganizeManageIPTUsers 			= new tcOrganizeManageIPTUsers(); // tc-3900
		tcServiceWorkTimeManage			ServiceWorkTimeManage 			= new tcServiceWorkTimeManage(); // tc-4000
		tcOrganizeACD				OrganizeACD 				= new tcOrganizeACD(); // tc-4100
		tcOrganizeCTIQueue			OrganizeCTIQueue			= new tcOrganizeCTIQueue(); // tc-4200
		tcOrganizeAgentGroup		OrganizeAgentGroup			= new tcOrganizeAgentGroup(); // tc-4300
		tcOrganizeAgentManage		OrganizeAgentManage			= new tcOrganizeAgentManage(); // tc-4400
		tcOrganizeSkillSet		OrganizeSkillSet			= new tcOrganizeSkillSet(); // tc-4500
		tcOrganizeSkillAgentAssign		OrganizeAgentSkillAssign			= new tcOrganizeSkillAgentAssign(); // tc-4600
		tcOrganizeIpAccess			OrganizeIpAccess 			= new tcOrganizeIpAccess(); //tc-5100
		tcOrganizeDnManage			OrganizeDnManage 			= new tcOrganizeDnManage(); //tc-5200
		tcOrganizeDidDnisConversion		OrganizeDidDnisConversion 		= new tcOrganizeDidDnisConversion(); //tc-5300
		tcServiceTotalTracking		ServiceTotalTracking		= new tcServiceTotalTracking(); //tc-10000
		tcinitialization			initialization			= new tcinitialization(); //tc-11000~12000
		
		
		test 				tc0001 = new test("tc-0001");
		
		/*
		 * date : 2016-12-07
		 * version : SWAT v2.3.0_b1 (2016-07-20)
		 * scenario : Test 湲곕낯 Data �벑濡�
		 * 湲곕뒫 : (�뀒�꼳�듃, �꽱�꽣愿�由�, �끂�뱶愿�由�, �끂�뱶蹂꾪뀒�꼳�듃�젙蹂�, IP�젒洹쇨�由�, 援��꽑愿�由�, 諛쒖떊�씪�슦�듃, 援먰솚湲고듅�닔肄붾뱶愿�由�, DID DNIS踰덊샇愿�由�, DN愿�由�, 
		 *        ACD, �긽�떞洹몃９, �긽�떞�궗愿�由�, �뒪�궗�뀑愿�由�, �긽�떞�궗蹂꾩뒪�궗�븷�떦, CTI�걧) TEST DATA�벑濡�
		 */
		
		//PhoneControlIP8815E			PhoneControl			= new PhoneControlIP8815E();
		//PhoneControl.test();
		
		/*
		tcLogin 				AUTO187 = new tcLogin("AUTO-187");
		
		
		ResourceCompany.test("tc-6000");
		ResourceTenant.test("tc-2010");
		ResourceCenterManage.test("tc-2210");
		ResourceNodeManage.test("tc-2310");
		ResourceTenantbyNode.test("tc-2410");
		OrganizeIpAccess.test("tc-5110");
		OrganizeEndPoint.test("tc-2705");
		OrganizeOutRouting.test("tc-2805");
		OrganizeSpecialCodeManage.test("tc-4205");
		OrganizeDIDDNISManage.test("tc-3005");
		OrganizeDnManage.test("tc-5205");
		OrganizeACD.test("tc-4105");
		OrganizeACD.test("tc-4130");
		OrganizeAgentGroup.test("tc-4305");
		OrganizeAgentManage.test("tc-4405");
		OrganizeSkillSet.test("tc-4505");
		OrganizeAgentSkillAssign.test("tc-4601");
		OrganizeCTIQueue.test("tc-4205");
		*/
		//ServiceTotalTracking.test("tc-10000"); //媛쒕컻以�
		
		/**
		 * date : 2017-02-27
		 * version : SWAT v2.2.0_b3h2 (2016-07-20)
		 * scenario : SWAT 珥덇린�솕 �떆�굹由ъ삤
		 * 湲곕뒫 : (�뀒�꼳�듃, �꽱�꽣愿�由�, �끂�뱶愿�由�, �끂�뱶蹂꾪뀒�꼳�듃�젙蹂�, IP�젒洹쇨�由�, 援��꽑愿�由�, 諛쒖떊�씪�슦�듃, 援먰솚湲고듅�닔肄붾뱶愿�由�, DID DNIS踰덊샇愿�由�, DN愿�由�, 
		 *        ACD, �긽�떞洹몃９, �긽�떞�궗愿�由�, �뒪�궗�뀑愿�由�, �긽�떞�궗蹂꾩뒪�궗�븷�떦, CTI�걧) TEST DATA �궘�젣
		 */
		//testcase.add("tc-12001"); //CTI�걧 �궘�젣
		//testcase.add("tc-12002"); //�뒪�궗�뀑 �궘�젣
		//testcase.add("tc-12003"); //�긽�떞�궗 �궘�젣
		//testcase.add("tc-12004"); //�긽�떞洹몃９�궘�젣 - 洹몃９�븞�뿉 洹몃９ �궘�젣 �떆 媛쒕컻 �븘�슂
		//testcase.add("tc-12005"); //ACD �궘�젣
		//testcase.add("tc-12006"); //DN �궘�젣
		//testcase.add("tc-12007"); //DID DNIS踰덊샇愿�由� �궘�젣
		//testcase.add("tc-12008"); //援먰솚湲� �듅�닔肄붾뱶愿�由� �궘�젣
		//testcase.add("tc-12009"); //諛쒖떊�씪�슦�듃 �궘�젣
		//testcase.add("tc-12010"); //援��꽑愿�由� �궘�젣
		//testcase.add("tc-12011"); //IP �젒洹쇨�由� �궘�젣
		//testcase.add("tc-12012"); //�끂�뱶蹂� �뀒�꼳�듃 �젙蹂� �궘�젣
		//testcase.add("tc-12013"); //�끂�뱶愿�由� �궘�젣
		//testcase.add("tc-12014"); //�꽱�꽣愿�由� �궘�젣
		//testcase.add("tc-12015"); //�뀒�꼳�듃 鍮꾪솢�꽦�솕
		//System.out.println(testcase);
		//initialization.test(testcase);
		
		/** 
		 * date : 2017-03-13
		 * version : SWAT v2.2.0_b3 (2017-02-03)
		 * scenario : Call Test 諛�  �넻�빀 �듃�젅�궧 寃��궗
		 * 湲� �뒫 : DID,DOD,DID-CTIQ-AGENT
		 * **/
		//tcICDevelopControl			icdevelopcontrol			= new tcICDevelopControl(); //tc-11000~12000
		//icdevelopcontrol.test("tc-99001");
		//icdevelopcontrol.test("tc-99002");
		//ServiceTotalTracking.test("tc-98000");
		//ServiceTotalTracking.test("tc-98001");

		//IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		//CTIStatTotalInbound.test("tc-0720");
		//System.exit(0);
				
		
/*
		int[] div = null;
		Map<Integer, java.util.List<String>> map_prev = new HashMap<Integer, java.util.List<String>>();
		Map<Integer, java.util.List<String>> map_post = new HashMap<Integer, java.util.List<String>>();
		java.util.List<String> expect = new ArrayList<>();
		boolean phone_status = false;
		try {
		    
		    ICDeveloper telephone4 = new ICDeveloper();
		    Map<String, String> tel_config = new HashMap<String, String>();
		    telephone4.init();
		    telephone4.clickMenu("AgentPage");
		    tel_config.put("TextIpAddr1", ICDev_ip1);
		    tel_config.put("TextIpAddr2", ICDev_ip2);
		    tel_config.put("TextStartDn", "2002");
		    tel_config.put("TextTenantName", "tnt");
		    tel_config.put("TextAgentID", "btagt2");
		    tel_config.put("TextAgentPasswd", "1");
		    tel_config.put("TextAgentDN", "2002");
		    tel_config.put("TextTenantName2", "tnt");
		    tel_config.put("Media Option", "Voice");
		    tel_config.put("TextAgtAgentID", "btagt2");
		    tel_config.put("TextAgtTenantName", "tnt");
		    tel_config.put("TextCallDN", "2002");
		    tel_config.put("TextCallDestDN", "934304199");
		    telephone4.set_inputs(tel_config);
		    if (telephone4.clickbutton("OpenServer")) {
			if (telephone4.clickbutton("Register")) {
			    if (telephone4.clickbutton("Login")) {
				if (telephone4.clickbutton("SetAftCallState")) {
				    phone_status = true;
				}
			    }
			}
		    }

		    ICDeveloper2 telephone5 = new ICDeveloper2();
		    telephone5.init();
		    telephone5.clickMenu("AgentPage");
		    tel_config.put("TextIpAddr1", ICDev_ip1);
		    tel_config.put("TextIpAddr2", ICDev_ip2);
		    tel_config.put("TextStartDn", "2003");
		    tel_config.put("TextTenantName", "tnt");
		    tel_config.put("TextAgentID", "btagt3");
		    tel_config.put("TextAgentPasswd", "1");
		    tel_config.put("TextAgentDN", "2003");
		    tel_config.put("TextTenantName2", "tnt");
		    tel_config.put("Media Option", "Voice");
		    tel_config.put("TextAgtAgentID", "btagt3");
		    tel_config.put("TextAgtTenantName", "tnt");
		    tel_config.put("TextCallDN", "2003");
		    tel_config.put("TextCallDestDN", "2002");
		    telephone5.set_inputs(tel_config);
		    if (telephone5.clickbutton("OpenServer")) {
			if (telephone5.clickbutton("Register")) {
			    if (telephone5.clickbutton("Login")) {
				if (telephone5.clickbutton("SetAftCallState")) {
				    phone_status = true;
				}
			    }
			}
		    }
		    
		    ICDeveloper3 telephone6 = new ICDeveloper3();
		    telephone6.init();
		    telephone6.clickMenu("AgentPage");
		    tel_config.put("TextIpAddr1", ICDev_ip1);
		    tel_config.put("TextIpAddr2", ICDev_ip2);
		    tel_config.put("TextStartDn", "2001");
		    tel_config.put("TextTenantName", "tnt");
		    tel_config.put("TextAgentID", "btagt1");
		    tel_config.put("TextAgentPasswd", "1");
		    tel_config.put("TextAgentDN", "2001");
		    tel_config.put("TextTenantName2", "tnt");
		    tel_config.put("Media Option", "Voice");
		    tel_config.put("TextAgtAgentID", "btagt1");
		    tel_config.put("TextAgtTenantName", "tnt");
		    tel_config.put("TextCallDN", "2001");
		    //tel_config.put("TextCallDestDN", "2002");
		    telephone6.set_inputs(tel_config);
		    if (telephone6.clickbutton("OpenServer")) {
			if (telephone6.clickbutton("Register")) {
			    if (telephone6.clickbutton("Login")) {
				if (telephone6.clickbutton("SetAftCallState")) {
				    phone_status = true;
				}
			    }
			}
		    }

		    ICDeveloper4 telephone7 = new ICDeveloper4();
		    telephone7.init();
		    telephone7.clickMenu("AgentPage");
		    tel_config.put("TextIpAddr1", ICDev_ip1);
		    tel_config.put("TextIpAddr2", ICDev_ip2);
		    tel_config.put("TextStartDn", "2004");
		    tel_config.put("TextTenantName", "tnt");
		    tel_config.put("TextAgentID", "btagt4");
		    tel_config.put("TextAgentPasswd", "1");
		    tel_config.put("TextAgentDN", "2004");
		    tel_config.put("TextTenantName2", "tnt");
		    tel_config.put("Media Option", "Voice");
		    tel_config.put("TextAgtAgentID", "btagt4");
		    tel_config.put("TextAgtTenantName", "tnt");
		    tel_config.put("TextCallDN", "2004");
		    //tel_config.put("TextCallDestDN", "2002");
		    telephone7.set_inputs(tel_config);
		    if (telephone7.clickbutton("OpenServer")) {
			if (telephone7.clickbutton("Register")) {
			    if (telephone7.clickbutton("Login")) {
				if (telephone7.clickbutton("SetAftCallState")) {
				    phone_status = true;
				}
			    }
			}
		    }

		    result = true;
		    Map<Integer, java.util.List<String>> iestattenant_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestattenant_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatextensionline_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatextensionline_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatendpoint_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatendpoint_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> counselorcallprocess_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> counselorcallprocess_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> systemtotalstat_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> systemtotalstat_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> counselorgroup_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> counselorgroup_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatrealinbound_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatrealinbound_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistattotalinbound_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistattotalinbound_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatacd_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatacd_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> counselorqueueskill_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> counselorqueueskill_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatqueuestandby_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatqueuestandby_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatqueueabandon_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatqueueabandon_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatskillset_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatskillset_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatansratiosl_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> ctistatansratiosl_post = new HashMap<Integer, java.util.List<String>>();

		    //==================================================================================================
		    //==================================================================================================
		    // �긽�떞�썝 濡쒓렇�씤
		    testID = "ts-10024"; // �넻�솕以� 李⑹떊�쟾�솚
		    result = true;
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2002"); 
		    telephone5.set_inputs(tel_config);
		    telephone7.set_inputs(tel_config);
		    OrganizeDnManage.test("tc-5229");
		    if (OrganizeDnManage.result) {
			    if (telephone5.clickbutton("MakeCall")) {
				Thread.sleep(5000);
				if (telephone4.get_ringing()) {
				    Thread.sleep(1000);
				    if (telephone4.clickbutton("AnswerCall")) {
					Thread.sleep(5000);
					if (telephone7.clickbutton("MakeCall")) {
					    Thread.sleep(5000);
					    if (telephone6.get_ringing()) {
						if (telephone6.clickbutton("AnswerCall")) { 
						    Thread.sleep(3000);
						    telephone7.clickbutton("ClearCall");
						    telephone5.clickbutton("ClearCall");
						} else result = false;
					    } else result = false;
					} else result = false;
				    } else result = false;
				} else result = false;
			    } else result = false;
		    } else result = false;
		    if (result == false) {
			telephone7.clickbutton("ClearCall");
			telephone5.clickbutton("ClearCall");			
		    }
		    OrganizeDnManage.test("tc-5230");
		    result = OrganizeDnManage.result;
		    if (OrganizeDnManage.result) {
			    if (telephone5.clickbutton("MakeCall")) {
				Thread.sleep(5000);
				if (telephone4.get_ringing()) {
				    Thread.sleep(1000);
				    if (telephone4.clickbutton("AnswerCall")) {
					Thread.sleep(5000);
					if (telephone5.clickbutton("ClearCall")) {
					    result = true;
					} else result = false;
				    } else result = false;
				} else result = false;
			    } else result = false;
		    }  else result = false;
		    System.out.println(result);
		    System.exit(0);

		    //==================================================================================================
		    //==================================================================================================
		    // �긽�떞�썝 濡쒓렇�씤
		    testID = "ts-10023"; // 臾댁쓳�떟 李⑹떊�쟾�솚
		    result = true;
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2002"); 
		    telephone5.set_inputs(tel_config);
		    OrganizeDnManage.test("tc-5228");
		    if (OrganizeDnManage.result) {
			    if (telephone5.clickbutton("MakeCall")) {
				Thread.sleep(25000);
				if (telephone6.get_ringing()) {
				    Thread.sleep(1000);
				    if (telephone6.clickbutton("AnswerCall")) {
					Thread.sleep(5000);
					if (telephone5.clickbutton("ClearCall")) {
					    result = true;
					} else result = false;
				    } else result = false;
				} else result = false;
			    } else result = false;
		    }  else result = false;
		    OrganizeDnManage.test("tc-5229");
		    result = OrganizeDnManage.result;
		    if (OrganizeDnManage.result) {
			    if (telephone5.clickbutton("MakeCall")) {
				Thread.sleep(5000);
				if (telephone4.get_ringing()) {
				    Thread.sleep(1000);
				    if (telephone4.clickbutton("AnswerCall")) {
					Thread.sleep(5000);
					if (telephone5.clickbutton("ClearCall")) {
					    result = true;
					} else result = false;
				    } else result = false;
				} else result = false;
			    } else result = false;
		    }  else result = false;
		    System.out.println(result);
		    System.exit(0);

		    //==================================================================================================
		    //==================================================================================================
		    // �긽�떞�썝 濡쒓렇�씤
		    testID = "ts-10022"; // 李⑹떊�쟾�솚
		    result = true;
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2002"); 
		    telephone5.set_inputs(tel_config);
		    OrganizeDnManage.test("tc-5225");
		    if (OrganizeDnManage.result) {
			    if (telephone5.clickbutton("MakeCall")) {
				Thread.sleep(5000);
				if (telephone6.get_ringing()) {
				    Thread.sleep(1000);
				    if (telephone6.clickbutton("AnswerCall")) {
					Thread.sleep(5000);
					if (telephone5.clickbutton("ClearCall")) {
					    result = true;
					} else result = false;
				    } else result = false;
				} else result = false;
			    } else result = false;
		    }  else result = false;
		    OrganizeDnManage.test("tc-5226");
		    result = OrganizeDnManage.result;
		    if (OrganizeDnManage.result) {
			    if (telephone5.clickbutton("MakeCall")) {
				Thread.sleep(5000);
				if (telephone4.get_ringing()) {
				    Thread.sleep(1000);
				    if (telephone4.clickbutton("AnswerCall")) {
					Thread.sleep(5000);
					if (telephone5.clickbutton("ClearCall")) {
					    result = true;
					} else result = false;
				    } else result = false;
				} else result = false;
			    } else result = false;
		    }  else result = false;
		    System.out.println(result);
		    System.exit(0);
		    //==================================================================================================
		    //==================================================================================================
		    //2003 -> 2002 answer -> call clear -> 2003 -> *12* -> 2002 answer
		    testID = "ts-10021"; // �샇 �쉶�떊
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2002"); 
		    telephone5.set_inputs(tel_config);
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			if (telephone4.get_ringing()) {
			    Thread.sleep(1000);
			    if (telephone4.clickbutton("AnswerCall")) {
				Thread.sleep(5000);
				if (telephone5.clickbutton("ClearCall")) {
				    telephone4.cleanup();
				    tel_config.clear();
				    tel_config.put("TextCallDestDN", "*12*"); 
				    telephone5.set_inputs(tel_config);
				    if (telephone5.clickbutton("MakeCall")) {
					Thread.sleep(5000);
					if (telephone4.get_ringing()) {
					    Thread.sleep(1000);
					    if (telephone4.clickbutton("AnswerCall")) {
						Thread.sleep(5000);
						if (telephone5.clickbutton("ClearCall")) {
						    System.out.println("Scenario success");
						} else result = false;
					    } else result = false;
					} else {
					    telephone5.clickbutton("ClearCall");
					    result = false;
					}
				    } else result = false;
				} else result = false;
			    } else result = false;
			} else {
			    telephone5.clickbutton("ClearCall");
			    result = false;
			}
		    } else result = false;
		    System.out.println("TS-10021: " + result);
		    System.exit(0);
		    
		    //==================================================================================================
		    //==================================================================================================
		    //2003 -> 2002 answer -> call clear -> 2002 -> *11* -> 2003 answer
		    testID = "ts-10020"; // �샇 �쉶�떊
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2002"); 
		    telephone5.set_inputs(tel_config);
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "*11*");
		    telephone4.set_inputs(tel_config);
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			if (telephone4.get_ringing()) {
			    if (telephone4.clickbutton("AnswerCall")) {
				Thread.sleep(2000);
				if (telephone5.clickbutton("ClearCall")) {
				    if (telephone4.clickbutton("MakeCall")) {
					Thread.sleep(3000);
					if (telephone5.get_ringing()) {
					    Thread.sleep(1000);
					    if (telephone5.clickbutton("AnswerCall")) {
						Thread.sleep(2000);
						if (telephone4.clickbutton("clearCall")) {
						    System.out.println("Success scenario");
						} else result = false;
					    } else result = false;
					} else result = false;
				    } else result = false;
				} else result = false;
			    } else result = false;
			} else result = false;
		    } else result = false;
		    System.out.println("RESULT: " + result);
		    System.exit(0);
		    //==================================================================================================
		    //==================================================================================================
		    //2003 -> 2200(CTI queue) -> 2001 -> 2002 answer -> 2200 (CTI queue) -> 2001 answer
		    testID = "ts-10019"; //RTIPB-41 洹몃９DN - �샇泥섎━

		    OrganizeCTIQueue.test("tc-4240");
		    if (OrganizeCTIQueue.result == false) {
			OrganizeCTIQueue.test("tc-4241");
			if (OrganizeCTIQueue.result == false) {
			    result = false;
			}
		    }

		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "90234304198"); // DNIS 4198 -> 2200
		    telephone5.set_inputs(tel_config);
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2200");
		    telephone4.set_inputs(tel_config);
		    
		    IEStatACD.test("tc-0612");
		    if (IEStatACD.result) iestatacd_prev.putAll(IEStatACD.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    CounselorCallProcess.test("tc-1520"); // �긽�떞�궗 �샇泥섎━ �넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map);
		    CounselorQueueSkill.test("tc-1720"); // �긽�떞�궗 �걧/�뒪�궗蹂� �넻怨�
		    if (CounselorQueueSkill.result) counselorqueueskill_prev.putAll(CounselorQueueSkill.map);
		    
		    CTIStatTotalInbound.test("tc-0720");
		    if (CTIStatTotalInbound.result) ctistattotalinbound_prev.putAll(CTIStatTotalInbound.map);
		    CTIStatRealInbound.test("tc-0820");
		    if (CTIStatRealInbound.result) ctistatrealinbound_prev.putAll(CTIStatRealInbound.map);
		    System.out.println("ctistatrealinbound_prev: " + ctistatrealinbound_prev.size());
		    CTIStatQueueStandby.test("tc-0920");
		    if (CTIStatQueueStandby.result) ctistatqueuestandby_prev.putAll(CTIStatQueueStandby.map);
		    CTIStatQueueAbandon.test("tc-1020");
		    if (CTIStatQueueAbandon.result) ctistatqueueabandon_prev.putAll(CTIStatQueueAbandon.map);
		    CTIStatSkillSet.test("tc-1120");
		    System.out.println("ctistatskillset_prev: " + ctistatskillset_prev.size());
		    if (CTIStatSkillSet.result) ctistatskillset_prev.putAll(CTIStatSkillSet.map);
		    CTIStatAnsRatioSL.test("tc-1320");
		    if (CTIStatAnsRatioSL.result) ctistatansratiosl_prev.putAll(CTIStatAnsRatioSL.map);
//System.exit(0);
		    telephone5.clickbutton("Logout");
		    telephone7.clickbutton("Logout");
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(40000);
			if (telephone6.get_ringing()) {
			    if (telephone6.clickbutton("AnswerCall")) {
				Thread.sleep(5000);
				if (telephone4.clickbutton("SetAgentState")) {
				    Thread.sleep(1000);
				    if (telephone6.clickbutton("SinglestepTransfer")) {
					Thread.sleep(3000);
					if (telephone4.get_ringing()) {
					    if (telephone4.clickbutton("AnswerCall")) {
						Thread.sleep(5000);
						if (!telephone5.clickbutton("ClearCall")) {
						    result = false;
						}
					    }
					}
				    }
				}
			    }
			}
		    }

		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    IEStatACD.test("tc-0612");
		    if (IEStatACD.result) iestatacd_post.putAll(IEStatACD.map);
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map); 
		    CounselorQueueSkill.test("tc-1720"); // �긽�떞�궗 �걧/�뒪�궗蹂� �넻怨�
		    if (CounselorQueueSkill.result) counselorqueueskill_post.putAll(CounselorQueueSkill.map);

		    CTIStatTotalInbound.test("tc-0720");
		    System.out.println("ctistattotalinbound_post: " + ctistattotalinbound_post.size());
		    if (CTIStatTotalInbound.result) ctistattotalinbound_post.putAll(CTIStatTotalInbound.map);
		    CTIStatRealInbound.test("tc-0820");
		    if (CTIStatRealInbound.result) ctistatrealinbound_post.putAll(CTIStatRealInbound.map);
		    CTIStatQueueStandby.test("tc-0920");
		    if (CTIStatQueueStandby.result) ctistatqueuestandby_post.putAll(CTIStatQueueStandby.map);
		    CTIStatQueueAbandon.test("tc-1020");
		    if (CTIStatQueueAbandon.result) ctistatqueueabandon_post.putAll(CTIStatQueueAbandon.map);
		    CTIStatSkillSet.test("tc-1120");
		    if (CTIStatSkillSet.result) ctistatskillset_post.putAll(CTIStatSkillSet.map);
		    System.out.println("ctistatskillset_post: " + ctistatskillset_post.size());
		    CTIStatAnsRatioSL.test("tc-1320");
		    if (CTIStatAnsRatioSL.result) ctistatansratiosl_post.putAll(CTIStatAnsRatioSL.map);

		    int[] ctitrans01 = {1,1,0,1,1,0,0,0,2,2};
		    div = ctitrans01.clone();
		    if (!comp(iestattenant_prev, iestattenant_post, div)) {
			result = false;
			System.out.println("RESULT5: " + result);
		    }
		    int[] ctitrans02 = {1,1,0,0,0,0,0,0,-1,0,0,0,0,0,1,1,-1};
		    div = ctitrans02.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT6: " + result);
		    }
		    int[] ctitrans03 = {2,0,0,0,0,2};
		    div = ctitrans03.clone();
		    if (!comp(iestatacd_prev, iestatacd_post, div)) {
			result = false;
			System.out.println("RESULT7: " + result);
		    }
		    int[] ctitrans04 = {1,1,0,0,0,0,0,0,1,1,0,0,2,2,0,0};
		    div = ctitrans04.clone();
		    if (!comp(iestatendpoint_prev, iestatendpoint_post, div)) {
			result = false;
			System.out.println("RESULT8: " + result);
		    }
		    int[] ctitrans05 = {2,1,0,0,1,-1,-1,0,-1,0,0,0,-1,-1,0,-1,0,-1,1,-1,1,0,0,-1,1,-1,-1};
		    div = ctitrans05.clone();
		    System.out.println("counselorcallprocess: " + counselorcallprocess_prev.size() + ":" + counselorcallprocess_post.size());
		    if (!comp(counselorcallprocess_prev, counselorcallprocess_post, div)) {
			result = false;
			System.out.println("RESULT9: " + result);
		    }
		    int[] ctitrans06 = {2,1,0,0,1,-1,-1};
		    div = ctitrans06.clone();
		    if (!comp(counselorqueueskill_prev, counselorqueueskill_post, div)) {
			result = false;
			System.out.println("RESULT10: " + result);
		    }
		    
		    int[] ctitrans07 = {2,1,0,0,1,1,0,0,1,0,0,0,-1,1,-1,0,-1,-1,-1,-1,-1,-1};
		    div = ctitrans07.clone();
		    if (!comp(ctistattotalinbound_prev, ctistattotalinbound_post, div)) {
			result = false;
			System.out.println("RESULT11: " + result);
		    }
		    int[] ctitrans08 = {1,1,0,0,0,0,-1,0,-1,0,-1,-1,-1,-1,-1,-1};
		    div = ctitrans08.clone();
		    if (!comp(ctistatrealinbound_prev, ctistatrealinbound_post, div)) {
			result = false;
			System.out.println("RESULT12: " + result);
		    }
		    int[] ctitrans09 = {2,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
		    div = ctitrans09.clone();
		    if (!comp(ctistatqueuestandby_prev, ctistatqueuestandby_post, div)) {
			result = false;
			System.out.println("RESULT13: " + result);
		    }
		    int[] ctitrans10 = {2,1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
		    div = ctitrans10.clone();
		    if (!comp(ctistatqueueabandon_prev, ctistatqueueabandon_post, div)) {
			result = false;
			System.out.println("RESULT14: " + result);
		    }
		    int[] ctitrans11 = {2,1,0,0,1,-1,1,-1,-1,-1,-1,-1,-1,-1};
		    div = ctitrans11.clone();
		    if (!comp(ctistatskillset_prev, ctistatskillset_post, div)) {
			result = false;
			System.out.println("RESULT15: " + result);
		    }
		    int[] ctitrans12 = {2,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
		    div = ctitrans12.clone();
		    if (!comp(ctistatansratiosl_prev, ctistatansratiosl_post, div)) {
			result = false;
			System.out.println("RESULT16: " + result);
		    }
		    System.exit(0);
		    
		    //==================================================================================================
		    //==================================================================================================
		    //2003 -> 2200(queue) -> 2001 -> 2002 -> 2200(queue) -> 2001 answer
		    testID = "ts-10018"; //RTIPB-41 洹몃９DN - �샇泥섎━
		    
		    OrganizeCTIQueue.test("tc-4240");
		    if (OrganizeCTIQueue.result == false) {
			OrganizeCTIQueue.test("tc-4241");
			if (OrganizeCTIQueue.result == false) {
			    result = false;
			}
		    }
		    
		    IEStatACD.test("tc-0612");
		    if (IEStatACD.result) iestatacd_prev.putAll(IEStatACD.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    CounselorCallProcess.test("tc-1520"); // �긽�떞�궗 �샇泥섎━ �넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map);
		    CounselorQueueSkill.test("tc-1720"); // �긽�떞�궗 �걧/�뒪�궗蹂� �넻怨�
		    if (CounselorQueueSkill.result) counselorqueueskill_prev.putAll(CounselorQueueSkill.map);
		    
		    CTIStatTotalInbound.test("tc-0720");
		    if (CTIStatTotalInbound.result) ctistattotalinbound_prev.putAll(CTIStatTotalInbound.map);
		    CTIStatRealInbound.test("tc-0820");
		    if (CTIStatRealInbound.result) ctistatrealinbound_prev.putAll(CTIStatRealInbound.map);
		    CTIStatQueueStandby.test("tc-0920");
		    if (CTIStatQueueStandby.result) ctistatqueuestandby_prev.putAll(CTIStatQueueStandby.map);
		    CTIStatQueueAbandon.test("tc-1020");
		    if (CTIStatQueueAbandon.result) ctistatqueueabandon_prev.putAll(CTIStatQueueAbandon.map);
		    CTIStatSkillSet.test("tc-1120");
		    System.out.println("CTIStatSkillSet.test: " + result);
		    if (CTIStatSkillSet.result) ctistatskillset_prev.putAll(CTIStatSkillSet.map);
		    CTIStatAnsRatioSL.test("tc-1320");
		    if (CTIStatAnsRatioSL.result) ctistatansratiosl_prev.putAll(CTIStatAnsRatioSL.map);
		    
		    System.out.println("CounselorCallProcess size: " + CounselorCallProcess.map.size());
		    System.out.println("CTIStatTotalInbound size: " + CTIStatTotalInbound.map.size());
		    System.out.println("CTIStatRealInbound size: " + CTIStatRealInbound.map.size());
		    System.out.println("CTIStatQueueStandby size: " + CTIStatQueueStandby.map.size());
		    System.out.println("CTIStatQueueAbandon size: " + CTIStatQueueAbandon.map.size());
		    System.out.println("CTIStatSkillSet size: " + CTIStatSkillSet.map.size() + ":" + ctistatskillset_prev.size());
		    System.out.println("CTIStatAnsRatioSL size: " + CTIStatAnsRatioSL.map.size());
		    
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "90234304198"); // DNIS 4198 -> 2200
		    telephone5.set_inputs(tel_config);
		    telephone5.clickbutton("Logout");
		    telephone7.clickbutton("Logout");
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(70000);
			if (telephone6.clickbutton("SetAgentState")) {
			    Thread.sleep(6000);
			    if (telephone6.get_ringing()) {
				if (telephone6.clickbutton("AnswerCall")) {
				    Thread.sleep(4000);
				    telephone5.clickbutton("ClearCall");
				}
			    }
			}
		    }
		    
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    IEStatACD.test("tc-0612");
		    if (IEStatACD.result) iestatacd_post.putAll(IEStatACD.map);
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map); 
		    CounselorQueueSkill.test("tc-1720"); // �긽�떞�궗 �걧/�뒪�궗蹂� �넻怨�
		    if (CounselorQueueSkill.result) counselorqueueskill_post.putAll(CounselorQueueSkill.map);

		    CTIStatTotalInbound.test("tc-0720");
		    if (CTIStatTotalInbound.result) ctistattotalinbound_post.putAll(CTIStatTotalInbound.map);
		    CTIStatRealInbound.test("tc-0820");
		    if (CTIStatRealInbound.result) ctistatrealinbound_post.putAll(CTIStatRealInbound.map);
		    CTIStatQueueStandby.test("tc-0920");
		    if (CTIStatQueueStandby.result) ctistatqueuestandby_post.putAll(CTIStatQueueStandby.map);
		    CTIStatQueueAbandon.test("tc-1020");
		    if (CTIStatQueueAbandon.result) ctistatqueueabandon_post.putAll(CTIStatQueueAbandon.map);
		    CTIStatSkillSet.test("tc-1120");
		    if (CTIStatSkillSet.result) ctistatskillset_post.putAll(CTIStatSkillSet.map);
		    System.out.println("ctistatskillset_post: " + ctistatskillset_post.size());
		    CTIStatAnsRatioSL.test("tc-1320");
		    if (CTIStatAnsRatioSL.result) ctistatansratiosl_post.putAll(CTIStatAnsRatioSL.map);

		    int[] ctiqueue12 = {1,1,0,1,1,0,0,0,2,2};
		    div = ctiqueue12.clone();
		    if (!comp(iestattenant_prev, iestattenant_post, div)) {
			result = false;
			System.out.println("RESULT5: " + result);
		    }
		    int[] ctiqueue15 = {1,1,0,0,0,0,0,0,-1,0,0,0,0,0,1,1,-1};
		    div = ctiqueue15.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT6: " + result);
		    }
		    int[] ctiqueue11 = {3,0,0,0,0,3};
		    div = ctiqueue11.clone();
		    if (!comp(iestatacd_prev, iestatacd_post, div)) {
			result = false;
			System.out.println("RESULT7: " + result);
		    }
		    int[] ctiqueue13 = {1,1,0,0,0,0,0,0,1,1,0,0,2,2,0,0};
		    div = ctiqueue13.clone();
		    if (!comp(iestatendpoint_prev, iestatendpoint_post, div)) {
			result = false;
			System.out.println("RESULT8: " + result);
		    }
		    int[] ctiqueue14 = {3,1,0,0,2,-1,-1,0,-1,0,0,0,-1,-1,0,-1,0,-1,0,-1,0,0,0,-1,1,-1,-1};
		    div = ctiqueue14.clone();
		    System.out.println("counselorcallprocess: " + counselorcallprocess_prev.size() + ":" + counselorcallprocess_post.size());
		    if (!comp(counselorcallprocess_prev, counselorcallprocess_post, div)) {
			result = false;
			System.out.println("RESULT9: " + result);
		    }
		    int[] ctiqueue16 = {3,1,0,0,2,-1,-1};
		    div = ctiqueue16.clone();
		    if (!comp(counselorqueueskill_prev, counselorqueueskill_post, div)) {
			result = false;
			System.out.println("RESULT10: " + result);
		    }
		    
		    int[] ctiqueue17 = {3,1,0,0,2,1,0,0,2,0,0,0,-1,1,-1,0,-1,-1,-1,-1,-1,-1};
		    div = ctiqueue17.clone();
		    if (!comp(ctistattotalinbound_prev, ctistattotalinbound_post, div)) {
			result = false;
			System.out.println("RESULT11: " + result);
		    }
		    int[] ctiqueue18 = {1,1,0,0,0,0,-1,0,-1,0,-1,-1,-1,-1,-1,-1};
		    div = ctiqueue18.clone();
		    if (!comp(ctistatrealinbound_prev, ctistatrealinbound_post, div)) {
			result = false;
			System.out.println("RESULT12: " + result);
		    }
		    int[] ctiqueue19 = {3,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
		    div = ctiqueue19.clone();
		    if (!comp(ctistatqueuestandby_prev, ctistatqueuestandby_post, div)) {
			result = false;
			System.out.println("RESULT13: " + result);
		    }
		    int[] ctiqueue20 = {3,1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
		    div = ctiqueue20.clone();
		    if (!comp(ctistatqueueabandon_prev, ctistatqueueabandon_post, div)) {
			result = false;
			System.out.println("RESULT14: " + result);
		    }
		    int[] ctiqueue21 = {3,1,0,0,2,-1,1,-1,-1,-1,-1,-1,-1,-1};
		    div = ctiqueue21.clone();
		    if (!comp(ctistatskillset_prev, ctistatskillset_post, div)) {
			result = false;
			System.out.println("RESULT15: " + result);
		    }
		    int[] ctiqueue22 = {3,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
		    div = ctiqueue22.clone();
		    if (!comp(ctistatansratiosl_prev, ctistatansratiosl_post, div)) {
			result = false;
			System.out.println("RESULT16: " + result);
		    }
		    System.exit(0);
		    
		    //==================================================================================================
		    //==================================================================================================
		    //2003 -> 2200(queue) -> 2001 -> 2002 -> 2200(queue) call cancel
		    testID = "ts-10017"; //RTIPB-41 洹몃９DN (ACD) - �샇泥섎━
		    OrganizeCTIQueue.test("tc-4240");
		    if (OrganizeCTIQueue.result == false) {
			OrganizeCTIQueue.test("tc-4241");
			if (OrganizeCTIQueue.result == false) {
			    result = false;
			}
		    }
		    IEStatACD.test("tc-0612");
		    
		    System.out.println("IEStatACD.test result: " + IEStatACD.result);
		    System.out.println("IEStatACD.test size: " + IEStatACD.map.size());
		    System.out.println("IEStatACD.test value: " + IEStatACD.map.get(0).toString());
		    if (IEStatACD.result) iestatacd_prev.putAll(IEStatACD.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    CounselorCallProcess.test("tc-1520"); // �긽�떞�궗 �샇泥섎━ �넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    CounselorQueueSkill.test("tc-1720"); // �긽�떞�궗 �걧/�뒪�궗蹂� �넻怨�
		    if (CounselorQueueSkill.result) counselorqueueskill_prev.putAll(CounselorQueueSkill.map);
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "90234304198"); // DNIS 4198 -> 2200
		    telephone5.set_inputs(tel_config);
		    telephone5.clickbutton("Logout");
		    telephone7.clickbutton("Logout");
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(35000);
			telephone5.clickbutton("ClearCall");
		    }
		    
		    IEStatACD.test("tc-0612");
		    if (IEStatACD.result) iestatacd_post.putAll(IEStatACD.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    CounselorQueueSkill.test("tc-1720"); // �긽�떞�궗 �걧/�뒪�궗蹂� �넻怨�
		    if (CounselorQueueSkill.result) counselorqueueskill_post.putAll(CounselorQueueSkill.map);
		    
		    int[] ctiqueue = {2,0,0,0,0,2};
		    div = ctiqueue.clone();
		    if (!comp(iestatacd_prev, iestatacd_post, div)) {
			result = false;
			System.out.println("RESULT5: " + result);
		    }
		    int[] ctiqueue1 = {1,1,0,1,0,0,0,0,1,1};
		    div = ctiqueue1.clone();
		    if (!comp(iestattenant_prev, iestattenant_post, div)) {
			result = false;
			System.out.println("RESULT6: " + result);
		    }
		    int[] ctiqueue3 = {1,1,0,0,0,0,0,0,1,1,0,0,2,2,0,0};
		    div = ctiqueue3.clone();
		    if (!comp(iestatendpoint_prev, iestatendpoint_post, div)) {
			result = false;
			System.out.println("RESULT7: " + result);
		    }
		    int[] ctiqueue4 = {1,0,0,0,1,-1,-1,0,-1, 0,0,0,-1,-1,0,-1, 0,-1, 0,-1,0,0, 0,-1, 0,-1,-1};
		    //int[] ctiqueue4 = {1,0,0,0,1,-1,-1};
		    div = ctiqueue4.clone();
		    if (!comp(counselorcallprocess_post, counselorcallprocess_post, div)) {
			result = false;
			System.out.println("RESULT8: " + result);
		    }
		    int[] ctiqueue5 = {1,1,0,0,0,0,0,0,-1,0,0,0,0,0,1,1,-1};
		    div = ctiqueue5.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT9: " + result);
		    }
		    int[] ctiqueue6 = {2,0,2,0,2,-1,-1};
		    div = ctiqueue6.clone();
		    if (!comp(counselorqueueskill_prev, counselorqueueskill_post, div)) {
			result = false;
			System.out.println("RESULT10: " + result);
		    }
		    System.exit(0);
		    
		    //==================================================================================================
		    //==================================================================================================
		    testID = "ts-10016"; //RTIPB-41 洹몃９DN (ACD) - �샇泥섎━
		    OrganizeACD.test("tc-4130"); // 洹몃９DN蹂� 硫ㅻ쾭愿�由� (2001,2002,2003 異붽�)
		    OrganizeACD.test("tc-4131"); // �뿄�똿 ���엯 > �닚李� 濡� �꽕�젙
		    IEStatACD.test("tc-0611");
		    if (IEStatACD.result) iestatacd_post.putAll(IEStatACD.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    //System.out.println("IEStatTenant: " + iestattenant_prev.get(0).toString());
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "90234304199");
		    //tel_config.put("AgentState2", "Not Ready");
		    //tel_config.put("AgentState", "Not Ready");
		    //telephone4.clickbutton("Logout");
		    //telephone5.clickbutton("Logout");
		    telephone5.set_inputs(tel_config);
		    //telephone5.clickbutton("SetAftCallState");
		    //telephone4.clickbutton("SetAftCallState");
		    Thread.sleep(5000);
		    if (telephone5.clickbutton("Login")) { 
			if (telephone5.clickbutton("MakeCall")) {
			    Thread.sleep(25000);
			    //telephone5.clickbutton("ClearCall");
			}
		    } else result = false;
		    System.out.println("RESULT4: " + result);

		    
		    IEStatACD.test("tc-0611");
		    if (IEStatACD.result) iestatacd_post.putAll(IEStatACD.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    //System.out.println("IEStatTenant: " + iestattenant_prev.get(0).toString());
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);

		    int[] acd = {0,0,0,0,1,0};
		    if (!comp(iestatacd_prev, iestatacd_post, div)) {
			result = false;
			System.out.println("RESULT5: " + result);
		    }
		    if (IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    int[] acd2 = {1,0,1,2,0,0,0,2,3,0};
		    div = null;
		    div = acd2.clone();
		    if (!comp(iestattenant_prev, iestattenant_post, div)) {
			result = false;
			System.out.println("RESULT6: " + result);
		    }
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    int[] acd3 = {1,0,0,0,0,0,0,1,1,0,0,1,2,0,1,1};
		    div = acd3.clone();
		    if (!comp(iestatendpoint_prev, iestatendpoint_post, div)) {
			result = false;
			System.out.println("RESULT7: " + result);
		    }
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    int[] acd4 = {1,1,0,0,0,0,0,0,-1,0,0,0,0,0,-1,1,-1};
		    div = acd4.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT8: " + result);
		    }
		    // OrganizeACD.test("tc-4132"); // �뿄�똿 ���엯 > �닚�솚 濡� �꽕�젙
		    System.exit(0);
		    //==================================================================================================
		    //==================================================================================================
		    testID = "ts-10015"; //RTIPB-25 DOD 理쒕� �쉶�꽑�닔
		    OrganizeEndPoint.test("tc-2742"); // DOD �쉶�꽑�닔瑜� 1濡� 議곗젅 in/out 媛� 1�뵫 �븘�슂

		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    //System.out.println("IEStatTenant: " + iestattenant_prev.get(0).toString());
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    //CTIStatRealInbound.test("tc-0820");
		    //if (CTIStatRealInbound.result) ctistatrealinbound_prev.putAll(CTIStatRealInbound.map);
		    //CTIStatTotalInbound.test("tc-0720");
		    //if (CTIStatTotalInbound.result) ctistattotalinbound_prev.putAll(CTIStatTotalInbound.map);
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "9116");
		    //tel_config.put("AgentState2", "Not Ready");
		    //tel_config.put("AgentState", "Not Ready");
		    //telephone4.clickbutton("Logout");
		    //telephone5.clickbutton("Logout");
		    telephone5.set_inputs(tel_config);
		    //telephone5.clickbutton("SetAftCallState");
		    telephone4.set_inputs(tel_config);
		    //telephone4.clickbutton("SetAftCallState");
		    Thread.sleep(5000);
		    if (telephone4.clickbutton("Login")) {
			if (telephone5.clickbutton("Login")) { 
        			if (telephone4.clickbutton("MakeCall")) {
        			    Thread.sleep(1000);
        			    telephone5.clickbutton("MakeCall");
        			    if (!telephone4.get_init()) {
        				result = false;
        				System.out.println("RESULT3: " + result);
        			    }
        			    Thread.sleep(5000);
        			    telephone4.clickbutton("ClearCall");
        			    Thread.sleep(1000);
        			    telephone5.clickbutton("ClearCall");
        			} else result = false;
			} else result = false;
		    } else result = false;
		    System.out.println("RESULT4: " + result);
		    
		    //SystemTotalStat.test("tc-0120"); //�떆�뒪�뀥蹂꾪넻�빀�넻怨�
		    //if (!SystemTotalStat.result) systemtotalstat_post.putAll(SystemTotalStat.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    //System.out.println("========================= " + iestattenant_post.get(0).toString());
		    if (IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    int[] tmp10 = {1,1,0,0,0,0,0,0,1,1};
		    div = null;
		    div = tmp10.clone();
		    if (!comp(iestattenant_prev, iestattenant_post, div)) {
			result = false;
			System.out.println("RESULT5: " + result);
		    }
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    int[] tmp14 = {1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0};
		    div = tmp14.clone();
		    if (!comp(iestatendpoint_prev, iestatendpoint_post, div)) {
			result = false;
			System.out.println("RESULT6: " + result);
		    }
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (!CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map);
		    //System.out.println("Counselor Call Process: " + counselorcallprocess_post);
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    int[] tmp12 = {2,1,0,0,0,1,0,0,-1,0,0,0,0,0,-1,1,-1};
		    div = tmp12.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT8: " + result);
		    }
		    
		    CTIStatRealInbound.test("tc-0820");
		    if (CTIStatRealInbound.result) ctistatrealinbound_post.putAll(CTIStatRealInbound.map);
		    int[] tmp19 = {0,0,0,0,0,0,-1,0,-1,0,-1,-1,-1,-1,-1,-1};
		    div = tmp19.clone();
		    if(!comp(ctistatrealinbound_prev, ctistatrealinbound_post, div)) {
			result = false;
			System.out.println("RESULT9: " + result);			
		    }
		    //System.out.println("CTIStatRealInbound: " + ctistatrealinbound_prev.get(0).toString());
		    //System.out.println("CTIStatRealInbound: " + ctistatrealinbound_post.get(0).toString());
		    CTIStatTotalInbound.test("tc-0720");
		    if (CTIStatTotalInbound.result) ctistattotalinbound_post.putAll(CTIStatTotalInbound.map);
		    int[] tmp18 = {0,0,0,0,0,0,0,0,0,0,0,0,-1,0,-1,0,-1,-1,-1,-1,-1};
		    div = tmp18.clone();
		    if(!comp(ctistattotalinbound_prev, ctistattotalinbound_post, div)) {
			result = false;
			System.out.println("RESULT10: " + result);			
		    }
		    //System.out.println("CTIStatTotalInbound: " + ctistattotalinbound_prev.get(0).toString());
		    //System.out.println("CTIStatTotalInbound: " + ctistattotalinbound_post.get(0).toString());
		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    OrganizeEndPoint.test("tc-2741"); // DID �쉶�꽑�닔瑜� 5濡� 議곗젅
		    System.out.println(testID + " result: " + result);
		    System.exit(0);
		    
		    //==================================================================================================
		    //==================================================================================================
		    testID = "ts-10014"; //RTIPB-24 DID 理쒕� �쉶�꽑�닔
		    OrganizeEndPoint.test("tc-2740"); // DID �쉶�꽑�닔瑜� 2濡� 議곗젅 in/out 媛� 1�뵫 �븘�슂

		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    //System.out.println("IEStatTenant: " + iestattenant_prev.get(0).toString());
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    CTIStatRealInbound.test("tc-0820");
		    if (CTIStatRealInbound.result) ctistatrealinbound_prev.putAll(CTIStatRealInbound.map);
		    CTIStatTotalInbound.test("tc-0720");
		    if (CTIStatTotalInbound.result) ctistattotalinbound_prev.putAll(CTIStatTotalInbound.map);
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "90234304199");
		    tel_config.put("AgentState2", "Not Ready");
		    tel_config.put("AgentState", "Not Ready");
		    telephone4.clickbutton("Logout");
		    telephone5.clickbutton("Logout");
		    telephone5.set_inputs(tel_config);
		    telephone5.clickbutton("SetAftCallState");
		    telephone4.set_inputs(tel_config);
		    telephone4.clickbutton("SetAftCallState");
		    Thread.sleep(5000);
		    if (telephone4.clickbutton("Login")) {
			if (telephone5.clickbutton("Login")) { 
        			if (telephone4.clickbutton("MakeCall")) {
        			    Thread.sleep(1000);
        			    telephone5.clickbutton("MakeCall");
        			    if (!telephone4.get_init()) {
        				result = false;
        				System.out.println("RESULT3: " + result);
        			    }
        			    Thread.sleep(5000);
        			    telephone4.clickbutton("ClearCall");
        			    Thread.sleep(1000);
        			    telephone5.clickbutton("ClearCall");
        			} else result = false;
			} else result = false;
		    } else result = false;
		    System.out.println("RESULT4: " + result);
		    
		    //SystemTotalStat.test("tc-0120"); //�떆�뒪�뀥蹂꾪넻�빀�넻怨�
		    //if (!SystemTotalStat.result) systemtotalstat_post.putAll(SystemTotalStat.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    //System.out.println("========================= " + iestattenant_post.get(0).toString());
		    if (IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    int[] tmp = {1,1,0,1,0,0,0,1,2,1};
		    div = null;
		    div = tmp.clone();
		    if (!comp(iestattenant_prev, iestattenant_post, div)) {
			result = false;
			System.out.println("RESULT5: " + result);
		    }
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    int[] tmp4 = {1,1,0,0,0,0,0,0,1,0,0,1,2,1,1,0};
		    div = tmp4.clone();
		    if (!comp(iestatendpoint_prev, iestatendpoint_post, div)) {
			result = false;
			System.out.println("RESULT6: " + result);
		    }
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (!CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map);
		    //System.out.println("Counselor Call Process: " + counselorcallprocess_post);
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    int[] tmp2 = {2,1,0,0,0,1,0,0,-1,0,0,0,0,0,-1,1,-1};
		    div = tmp2.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT8: " + result);
		    }
		    
		    CTIStatRealInbound.test("tc-0820");
		    if (CTIStatRealInbound.result) ctistatrealinbound_post.putAll(CTIStatRealInbound.map);
		    int[] tmp9 = {1,0,1,0,0,0,-1,0,-1,0,-1,-1,-1,-1,-1,-1};
		    div = tmp9.clone();
		    if(!comp(ctistatrealinbound_prev, ctistatrealinbound_post, div)) {
			result = false;
			System.out.println("RESULT9: " + result);			
		    }
		    //System.out.println("CTIStatRealInbound: " + ctistatrealinbound_prev.get(0).toString());
		    //System.out.println("CTIStatRealInbound: " + ctistatrealinbound_post.get(0).toString());
		    CTIStatTotalInbound.test("tc-0720");
		    if (CTIStatTotalInbound.result) ctistattotalinbound_post.putAll(CTIStatTotalInbound.map);
		    int[] tmp15 = {1,1,0,0,0,0,1,0,0,0,0,0,-1,0,-1,0,-1,-1,-1,-1,-1};
		    div = tmp15.clone();
		    if(!comp(ctistattotalinbound_prev, ctistattotalinbound_post, div)) {
			result = false;
			System.out.println("RESULT10: " + result);			
		    }
		    //System.out.println("CTIStatTotalInbound: " + ctistattotalinbound_prev.get(0).toString());
		    //System.out.println("CTIStatTotalInbound: " + ctistattotalinbound_post.get(0).toString());
		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    OrganizeEndPoint.test("tc-2741"); // DID �쉶�꽑�닔瑜� 5濡� 議곗젅
		    System.out.println(testID + " result: " + result);
		    System.exit(0);
		    
		    //==================================================================================================
		    //==================================================================================================
		    testID = "ts-10013"; //RTIPB-22 �닔�떊踰덊샇 李⑤떒 (ANI 踰덊샇 李⑤떒)

		    OrganizeDIDDNISManage.test("tc-3020"); // DNIS 4199 寃��깋 DNIS 踰덊샇愿�由� 異붽� 4199->2002
		    if (OrganizeDIDDNISManage.result == false) {
			//tc-3021
			OrganizeDIDDNISManage.test("tc-3021");
			if (!OrganizeDIDDNISManage.result) result = false;
			System.out.println("RESULT1: " + result);
		    } else {
			//tc-3022
			OrganizeDIDDNISManage.test("tc-3022");
			if (!OrganizeDIDDNISManage.result) result = false;
			System.out.println("RESULT2: " + result);
		    }
		    //SystemTotalStat.test("tc-0120"); //�떆�뒪�뀥蹂꾪넻�빀�넻怨�
		    //if (!SystemTotalStat.result) systemtotalstat_prev.putAll(SystemTotalStat.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    if (IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    //System.out.println("IEStatTenant: " + iestattenant_prev.get(0).toString());
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "90234304199");
		    telephone5.set_inputs(tel_config);
		    
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(3000);
			if (!telephone5.get_dialing()) {
			    result = false;
			    System.out.println("RESULT3: " + result);
			}
			telephone5.clickbutton("ClearCall");
		    } else result = false;
		    System.out.println("RESULT4: " + result);
		    //SystemTotalStat.test("tc-0120"); //�떆�뒪�뀥蹂꾪넻�빀�넻怨�
		    //if (!SystemTotalStat.result) systemtotalstat_post.putAll(SystemTotalStat.map);
		    IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    //System.out.println("========================= " + iestattenant_post.get(0).toString());
		    if (IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    int[] tmp1 = {1,0,1,1,0,0,0,1,2,0};
		    div = null;
		    div = tmp1.clone();
		    if (!comp(iestattenant_prev, iestattenant_post, div)) {
			result = false;
			System.out.println("RESULT5: " + result);
		    }
		    IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    if (IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    int[] tmp5 = {1,0,0,0,0,1,0,0,1,0,0,1,2,0,1,1};
		    div = tmp5.clone();
		    if (!comp(iestatendpoint_prev, iestatendpoint_post, div)) {
			result = false;
			System.out.println("RESULT6: " + result);
		    }
		    CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    if (!CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map);
		    //System.out.println("Counselor Call Process: " + counselorcallprocess_post);
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    int[] tmp6 = {1,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0};
		    div = tmp6.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT8: " + result);
		    }
		    
		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    
		    System.out.println(testID + " result: " + result);
		    System.exit(0);

		    //==================================================================================================
		    //==================================================================================================
		    testID = "ts-10013"; //RTIPB-19 �닔�떊痍⑥냼
*/
		    /*
		    Map<Integer, java.util.List<String>> iestattenant_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestattenant_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatextensionline_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatextensionline_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatendpoint_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> iestatendpoint_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> counselorcallprocess_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> counselorcallprocess_post = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> systemtotalstat_prev = new HashMap<Integer, java.util.List<String>>();
		    Map<Integer, java.util.List<String>> systemtotalstat_post = new HashMap<Integer, java.util.List<String>>();
		    */
/*
		    OrganizeDIDDNISManage.test("tc-3020"); // DNIS 4199 寃��깋
		    if (OrganizeDIDDNISManage.result == false) {
			//tc-3021
			OrganizeDIDDNISManage.test("tc-3021");
			if (!OrganizeDIDDNISManage.result) result = false;
			System.out.println("RESULT1: " + result);
		    } else {
			//tc-3022
			OrganizeDIDDNISManage.test("tc-3022");
			if (!OrganizeDIDDNISManage.result) result = false;
			System.out.println("RESULT2: " + result);
		    }
		    //SystemTotalStat.test("tc-0120"); //�떆�뒪�뀥蹂꾪넻�빀�넻怨�
		    //if (!SystemTotalStat.result) systemtotalstat_prev.putAll(SystemTotalStat.map);
		    //IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    //if (!IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    //IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    //if (!IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    //CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    //if (!CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2002");
		    telephone5.set_inputs(tel_config);
		    
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(3000);
			if (!telephone4.get_ringing()) {
			    result = false;
			    System.out.println("RESULT3: " + result);
			}
			telephone4.clickbutton("ClearCall");
		    } else result = false;
		    System.out.println("RESULT4: " + result);
		    //SystemTotalStat.test("tc-0120"); //�떆�뒪�뀥蹂꾪넻�빀�넻怨�
		    //if (!SystemTotalStat.result) systemtotalstat_post.putAll(SystemTotalStat.map);
		    //IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    //if (!IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    //IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    //if (!IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    //CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    //if (!CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    System.out.println("Compare!!");
		    int[] div3 = {1,0,0,0,0,0,0,1,0,1,0,0,1,0,2,0,0};
		    div = div3.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT5: " + result);
		    }
		    
		    iestatextensionline_prev.putAll(iestatextensionline_post);
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "90234304199");
		    telephone5.set_inputs(tel_config);
		    
		    
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(3000);
			if (!telephone4.get_ringing()) {
			    result = false;
			    System.out.println("RESULT6: " + result);
			}
			telephone4.clickbutton("ClearCall");
			Thread.sleep(1000);
			telephone5.clickbutton("ClearCall");
		    } else {
			result = false;
			System.out.println("RESULT7: " + result);
		    }
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    System.out.println("Compare!!");
		    System.out.println("1st: " + iestatextensionline_prev.get(0));
		    System.out.println("2nd: " + iestatextensionline_post.get(0));
		    int[] div4 = {1,0,0,0,0,1,0,0,0,1,0,0,1,0,2,0,0};
		    div = div4.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
			System.out.println("RESULT8: " + result);
		    }

		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    
		    System.out.println(testID + " result: " + result);
		    System.exit(0);


		    //==================================================================================================
		    //==================================================================================================
		    testID = "ts-10012"; //RTIPB-18 諛쒖떊痍⑥냼

		    //Map<Integer, java.util.List<String>> iestattenant_prev = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> iestattenant_post = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> iestatextensionline_prev = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> iestatextensionline_post = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> iestatendpoint_prev = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> iestatendpoint_post = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> counselorcallprocess_prev = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> counselorcallprocess_post = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> systemtotalstat_prev = new HashMap<Integer, java.util.List<String>>();
		    //Map<Integer, java.util.List<String>> systemtotalstat_post = new HashMap<Integer, java.util.List<String>>();

		    OrganizeDIDDNISManage.test("tc-3020"); // DNIS 4199 寃��깋
		    if (OrganizeDIDDNISManage.result == false) {
			//tc-3021
			OrganizeDIDDNISManage.test("tc-3021");
			if (!OrganizeDIDDNISManage.result) result = false;
		    } else {
			//tc-3022
			OrganizeDIDDNISManage.test("tc-3022");
			if (!OrganizeDIDDNISManage.result) result = false;
		    }
		    //SystemTotalStat.test("tc-0120"); //�떆�뒪�뀥蹂꾪넻�빀�넻怨�
		    //if (!SystemTotalStat.result) systemtotalstat_prev.putAll(SystemTotalStat.map);
		    //IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    //if (!IEStatTenant.result) iestattenant_prev.putAll(IEStatTenant.map);
		    //IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    //if (!IEStatEndPoint.result) iestatendpoint_prev.putAll(IEStatEndPoint.map);
		    //CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    //if (!CounselorCallProcess.result) counselorcallprocess_prev.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_prev.putAll(IEStatExtensionLine.map);
		    
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2002");
		    telephone5.set_inputs(tel_config);
		    
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(3000);
			if (!telephone4.get_ringing()) {
			    result = false;
			}
			telephone5.clickbutton("ClearCall");
		    } else result = false;

		    //SystemTotalStat.test("tc-0120"); //�떆�뒪�뀥蹂꾪넻�빀�넻怨�
		    //if (!SystemTotalStat.result) systemtotalstat_post.putAll(SystemTotalStat.map);
		    //IEStatTenant.test("tc-0220");//�뀒�꼳�듃蹂� �닔/諛쒖떊 吏묎퀎
		    //if (!IEStatTenant.result) iestattenant_post.putAll(IEStatTenant.map);
		    //IEStatEndPoint.test("tc-0420");//EndPoint �샇泥섎━ 吏묎퀎
		    //if (!IEStatEndPoint.result) iestatendpoint_post.putAll(IEStatEndPoint.map);
		    //CounselorCallProcess.test("tc-1520");//�긽�떞�궗�샇泥섎━�넻怨�
		    //if (!CounselorCallProcess.result) counselorcallprocess_post.putAll(CounselorCallProcess.map); 
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    System.out.println("Compare!!");
		    System.out.println("1st: " + iestatextensionline_prev.get(0));
		    System.out.println("2nd: " + iestatextensionline_post.get(0));
		    int[] div5 = {1,0,0,0,0,1,0,0,0,1,0,0,1,0,2,0,0};
		    div = div5.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
		    }
		    
		    iestatextensionline_prev.putAll(iestatextensionline_post);
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "90234304124");
		    telephone5.set_inputs(tel_config);
		    
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(3000);
			if (!telephone5.get_dialing()) {
			    result = false;
			}
			telephone5.clickbutton("ClearCall");
		    } else result = false;
		    IEStatExtensionLine.test("tc-0320");//�궡�꽑�쉶�꽑�닔/諛쒖떊吏묎퀎
		    if (IEStatExtensionLine.result) iestatextensionline_post.putAll(IEStatExtensionLine.map);
		    System.out.println("Compare!!");
		    System.out.println("1st: " + iestatextensionline_prev.get(0));
		    System.out.println("2nd: " + iestatextensionline_post.get(0));
		    int[] div6 = {1,0,0,0,0,1,0,0,0,1,0,0,1,0,2,0,0};
		    div = div6.clone();
		    if (!comp(iestatextensionline_prev, iestatextensionline_post, div)) {
			result = false;
		    }
		    
		    
		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    
		    System.out.println(testID + " result: " + result);
		    System.exit(0);

		    //==================================================================================================
		    //==================================================================================================
		    testID = "ts-10011"; //RTIPB-18
		    chrometerminal terminal = new chrometerminal();
		    terminal.init();
		    terminal.login();
		    terminal.get_ipron();
		    terminal.send_commands("icli");
		    terminal.send_commands("ie.calls");
		    System.out.println(terminal.last_msg.toString());
		    
		    map_prev.clear();
		    map_post.clear();
		    int[] diff = {1,0,0,0,0,1,0,0,0,1,0,0,1,0,2,0,0}; 
		    IEStatExtensionLine.test("tc-0350");
		    map_prev.putAll(IEStatExtensionLine.map);

		    if (terminal.last_msg.contains("TOTAL")) {
			if (!terminal.last_msg.get(terminal.last_msg.size() - 2).replaceAll(" ", "").contains("TOTAL[0/0]")) {
			    result = false;
			}
		    }
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(3000);
			telephone5.clickbutton("ClearCall");
		    } else result = false;
		    terminal.send_commands("ie.calls");
		    System.out.println(terminal.last_msg.toString());
		    if (terminal.last_msg.contains("TOTAL")) {
			if (!terminal.last_msg.get(terminal.last_msg.size() - 2).replaceAll(" ", "").contains("TOTAL[0/0]")) {
			    result = false;
			}
		    }
		    
		    IEStatExtensionLine.test("tc-0350");
		    map_post.putAll(IEStatExtensionLine.map);
		    expect.clear();
		    //java.util.List<String> expect = new ArrayList<>();
		    for (int i = 0; i < map_prev.get(0).size(); i++) {
			expect.add(Integer.toString(Integer.parseInt(map_prev.get(0).get(i)) + diff[i]));
		    }
		    System.out.println(map_prev.get(0));
		    System.out.println(map_post.get(0));
		    System.out.println(expect.toString());
		    if (!expect.toString().equals(map_post.get(0).toString())) {
			result = false;
		    }
		    // -------------------------------------------------------------------------------------------------
		    map_prev.clear();
		    map_post.clear();
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "934304124");
		    telephone5.set_inputs(tel_config);
		    int[] tmp3 = {1,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0};
		    diff = tmp3.clone();
		    IEStatExtensionLine.test("tc-0350");
		    map_prev.putAll(IEStatExtensionLine.map);

		    if (terminal.last_msg.contains("TOTAL")) {
			if (!terminal.last_msg.get(terminal.last_msg.size() - 2).replaceAll(" ", "").contains("TOTAL[0/0]")) {
			    result = false;
			}
		    }
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(3000);
			telephone5.clickbutton("ClearCall");
		    } else result = false;
		    terminal.send_commands("ie.calls");
		    System.out.println(terminal.last_msg.toString());
		    if (terminal.last_msg.contains("TOTAL")) {
			if (!terminal.last_msg.get(terminal.last_msg.size() - 2).replaceAll(" ", "").contains("TOTAL[0/0]")) {
			    result = false;
			}
		    }
		    
		    IEStatExtensionLine.test("tc-0350");
		    map_post.putAll(IEStatExtensionLine.map);
		    expect.clear();
//		    java.util.List<String> expect = new ArrayList<>();
		    for (int i = 0; i < map_prev.get(0).size(); i++) {
			expect.add(Integer.toString(Integer.parseInt(map_prev.get(0).get(i)) + diff[i]));
		    }
		    System.out.println(map_prev.get(0));
		    System.out.println(map_post.get(0));
		    System.out.println(expect.toString());
		    if (!expect.toString().equals(map_post.get(0).toString())) {
			result = false;
		    }

		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    
		    System.out.println("TS-10011 result: " + result);
		    System.exit(0);
		    //==================================================================================================
		    //==================================================================================================

		    testID = "ts-10010"; //RTIPB-17
		    map_prev.clear();
		    map_post.clear();
		    
		    int[] tmp7 = {1,1,0,0,0,0,0,0,10,1,1,0,0,10,2,2,10};
		    diff = tmp7.clone();
		    IEStatExtensionLine.test("tc-0350");
		    map_prev.putAll(IEStatExtensionLine.map);
		    
		    if (telephone5.clickbutton("MakeCall")) {
			Thread.sleep(2000);
			telephone4.clickbutton("AnswerCall");
			Thread.sleep(5500);
			telephone5.clickbutton("ClearCall");
		    } else result = false;
		    
		    IEStatExtensionLine.test("tc-0350");
		    map_post.putAll(IEStatExtensionLine.map);
		    expect.clear();
//		    java.util.List<String> expect = new ArrayList<>();
		    for (int i = 0; i < map_prev.get(0).size(); i++) {
			expect.add(Integer.toString(Integer.parseInt(map_prev.get(0).get(i)) + diff[i]));
		    }
		    System.out.println(map_prev.get(0));
		    System.out.println(map_post.get(0));
		    System.out.println(expect.toString());
		    if (!expect.toString().equals(map_post.get(0).toString())) {
			result = false;
		    }
		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    System.exit(0);
		    
		    testID = "ts-10003"; //RTIPB-14
		    ResourceTenantbyNode.test("tc-2430");
		    if (telephone4.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			telephone4.clickbutton("ClearCall");
		    } else result = false;
		    tel_config.clear();
		    tel_config.put("TextCallDestDN", "2003");
		    telephone4.set_inputs(tel_config);
		    ResourceTenantbyNode.test("tc-2431");
		    if (telephone4.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			telephone4.clickbutton("ClearCall");
		    } else result = false;
		    ResourceTenantbyNode.test("tc-2432");
		    if (telephone4.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			telephone4.clickbutton("ClearCall");
		    } else result = false;
		    ResourceTenantbyNode.test("tc-2433");
		    OrganizeDnManage.test("tc-5210");
		    if (OrganizeDnManage.result == false) result = true;
		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    ResourceTenantbyNode.test("tc-2439");
		    System.exit(0);
		    
		    
		    
		    testID = "ts-10002"; // RTIPB-13
		    ServiceWorkTimeManage.test("tc-4001");
		    ResourceTenantbyNode.test("tc-2405");
		    if (!ServiceWorkTimeManage.result) result = false;
		    if (telephone4.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			telephone4.clickbutton("ClearCall");
		    } else result = false;

		    ResourceTenantbyNode.test("tc-2406");
		    if (!ServiceWorkTimeManage.result) result = false;
		    if (telephone4.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			telephone4.clickbutton("ClearCall");
		    } else result = false;

		    ResourceTenantbyNode.test("tc-2407");
		    if (!ServiceWorkTimeManage.result) result = false;
		    if (telephone4.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			telephone4.clickbutton("ClearCall");
		    } else result = false;

		    ServiceWorkTimeManage.test("tc-4011");
		    ResourceTenantbyNode.test("tc-2405");
		    if (!ServiceWorkTimeManage.result) result = false;
		    if (telephone4.clickbutton("MakeCall")) {
			Thread.sleep(5000);
			telephone4.clickbutton("ClearCall");
		    } else result = false;
		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    
		    
		    testID = "ts-10001"; // RTIPB-12
*/
		    /**
		     *  �옄�썝愿�由� > �꽱�꽣�끂�뱶 > �끂�뱶蹂� �뀒�꼳�듃 �젙蹂� �뿉�꽌 �옄�룞援��꽑 �꽕�젙
		     *  7�옄由щ줈 �꽕�젙�븯怨� PREFIX�뒗 9瑜� 異붽�
		     *  9 prefix�뾾�씠 7�옄由� �꽆�뒗踰덊샇濡� 諛쒖떊�썑 李⑹떊�씠 �릺�뒗吏� �솗�씤
		     *  �옄�룞援��꽑諛쒖떊 �빐�젣 �썑 諛쒖떊 �떎�뙣�븯�뒗吏� �솗�씤
		     */
/*
		    ResourceTenantbyNode.test("tc-2420");
		    if (!ResourceTenantbyNode.result) result = false;
		    
		    telephone4.clickMenu("AgentPage");
		    tel_config.put("TextIpAddr1", ICDev_ip1);
		    tel_config.put("TextIpAddr2", ICDev_ip2);
		    tel_config.put("TextStartDn", "2002");
		    tel_config.put("TextTenantName", "tnt");
		    tel_config.put("TextAgentID", "btagt2");
		    tel_config.put("TextAgentPasswd", "1");
		    tel_config.put("TextAgentDN", "2002");
		    tel_config.put("TextTenantName2", "tnt");
		    tel_config.put("Media Option", "Voice");
		    tel_config.put("TextAgtAgentID", "btagt2");
		    tel_config.put("TextAgtTenantName", "tnt");
		    tel_config.put("TextCallDN", "2002");
		    tel_config.put("TextCallDestDN", "01025740253");
		    telephone4.set_inputs(tel_config);
		    if (telephone4.clickbutton("OpenServer")) {
			if (telephone4.clickbutton("Register")) {
			    if (telephone4.clickbutton("Login")) {
				if (telephone4.clickbutton("SetAgentState")) {
				    if (telephone4.clickbutton("MakeCall")) {
					Thread.sleep(5000);
					telephone4.clickbutton("ClearCall");
				    } else result = false;
				} else result = false;
			    } else result = false;
			} else result = false;
		    } else result = false;
		    
		    ResourceTenantbyNode.test("tc-2420");
		    if (!ResourceTenantbyNode.result) result = false;

		    if (telephone4.clickbutton("SetAgentState")) {
			if (telephone4.clickbutton("MakeCall")) {
			    Thread.sleep(5000);
			    telephone4.clickbutton("ClearCall");
			} else result = false;
		    } else result = false;
		    tel_config.clear();
		    
		    retString = errReason.err + "\n";// + cond.getStat();
		    results.add(testID, result, retString, null);
		    Thread.sleep(1000);
		    
		    result = true;
		    testID = "ts-10002";
*/
		    /**
		     *  �옄�썝愿�由� > �꽱�꽣�끂�뱶 > �끂�뱶蹂� �뀒�꼳�듃 �젙蹂� �꽕�젙
		     *  �뾽臾댁떆媛� �쇅 �샃�뀡 �꽕�젙
		     * "DID�뾽臾댁떆媛� �꽕�젙"�쓣 �꽕�젙 �븳 �썑 "DID�뾽臾댁떆媛� �쇅 �젣�뼱" �썑 �샇醫낅즺 �솗�씤
		     * "DID�뾽臾댁떆媛� �꽕�젙"�쓣 �꽕�젙 �븳 �썑 "DID�뾽臾댁떆媛� �쇅 �젣�뼱"�뿉 李⑹떊�쟾�솚�쓣 �꽑�깮, "李⑹떊�쟾�솚�떆DNIS"瑜� �꽕�젙�썑 �샇�쟾�솚 �솗�씤
		     * "DID�뾽臾댁떆媛� �꽕�젙"�쓣 �꽕�젙 �븳 �썑 "DID�뾽臾댁떆媛� �쇅 �젣�뼱"�뿉 李⑹떊�쟾�솚�쓣 �꽑�깮, "李⑹떊�쟾�솚�떆DNIS"瑜� �꽕�젙. 硫섑듃 �썑 �샇 醫낅즺 �솗�씤
		     * "DID�뾽臾댁떆媛� �꽕�젙"�쓣 �꽕�젙 �븳 �썑 "DID�뾽臾댁떆媛� �쇅 �젣�뼱"�뿉 李⑹떊�쟾�솚�쓣 �꽑�깮, "李⑹떊�쟾�솚�떆DNIS"瑜� �꽕�젙 硫섑듃 �썑 �샇 �쟾�솚 �솗�씤
		     */

		    
/*		    
		    System.exit(0);

		    
        		ICDeveloper telephone3 = new ICDeveloper();
            		//Map<String, String> tel_config = new HashMap<String, String>();
            		telephone3.init();
            		telephone3.clickMenu("AgentPage");
            		tel_config.put("TextIpAddr1", ICDev_ip1);
            		tel_config.put("TextIpAddr2", ICDev_ip2);
            		tel_config.put("TextStartDn", "2002");
            		tel_config.put("TextTenantName", "tnt");
            		tel_config.put("TextAgentID", "btagt2");
            		tel_config.put("TextAgentPasswd", "1");
            		tel_config.put("TextAgentDN", "2002");
            		tel_config.put("TextTenantName2", "tnt");
            		tel_config.put("Media Option", "Voice");
            		tel_config.put("TextAgtAgentID", "btagt2");
            		tel_config.put("TextAgtTenantName", "tnt");
            		tel_config.put("TextCallDN", "2002");
            		tel_config.put("TextCallDestDN", "9116");
            		telephone3.set_inputs(tel_config);
            		if (telephone3.clickbutton("OpenServer"))
            		if (telephone3.clickbutton("Register"))
        		if (telephone3.clickbutton("Login"))
        		if (telephone3.clickbutton("SetAgentState"))
        		if (telephone3.clickbutton("MakeCall")) {
        		    Thread.sleep(5000);
        		    telephone3.clickbutton("ClearCall");
        		}
        		tel_config.clear();
		} catch (Exception e) {
		    System.out.println(e);
		}
    		System.exit(0);
		
		//OrganizeManageIPTUsers.test("tc-3910");
		OrganizeManageIPTUsers.test("tc-3960");
		System.exit(0);
		OrganizeManageIPTUsers.test("tc-3950");
		OrganizeManageIPTUsers.test("tc-3940");
		OrganizeManageIPTUsers.test("tc-3930");
		OrganizeManageIPTUsers.test("tc-3920");
		OrganizeManageIPTUsers.test("tc-3910");
		OrganizeManageIPTUsers.test("tc-3900");
		OrganizeManageIPTOrganizationChart.test("tc-3820");
		OrganizeManageIPTOrganizationChart.test("tc-3810");
		OrganizeManageIPTOrganizationChart.test("tc-3800");
		OrganizeCOSConfig.test("tc-3720");
		OrganizeCOSConfig.test("tc-3710");
		OrganizeOutboundControlGroup.test("tc-3620");
		OrganizeOutboundControlGroup.test("tc-3610");
		OrganizeOutboundControlGroup.test("tc-3600");
		OrganizeIPAccessControl.test("tc-3520");
		OrganizeIPAccessControl.test("tc-3510");
		OrganizeIPAccessControl.test("tc-3500");
		OrganizeSwitchMentFileManage.test("tc-3400"); // 援먰솚湲� 硫섑듃 �뙆�씪 愿�由� 湲곕뒫�뿉 ���븳 �솗�씤�씠 �븘�슂�븿.
		OrganizeDODNumberManage.test("tc-3321");
		OrganizeDODNumberManage.test("tc-3311");
		OrganizeDODNumberManage.test("tc-3320");
		OrganizeDODNumberManage.test("tc-3310");
		OrganizeDODNumberManage.test("tc-3300");
		OrganizeDIDDenyNumberManage.test("tc-3214");
		OrganizeDIDDenyNumberManage.test("tc-3212");
		OrganizeDIDDenyNumberManage.test("tc-3211");
		OrganizeDIDDenyNumberManage.test("tc-3210");
		OrganizeDIDANIExchange.test("tc-3114");
		OrganizeDIDANIExchange.test("tc-3113");
		OrganizeDIDANIExchange.test("tc-3112");
		OrganizeDIDANIExchange.test("tc-3111");
		OrganizeDIDANIExchange.test("tc-3110");
		OrganizeDIDANIExchange.test("tc-3102");
		OrganizeDIDANIExchange.test("tc-3101");
		OrganizeDIDANIExchange.test("tc-3100");
		OrganizeDIDDNISManage.test("tc-3014");
		OrganizeDIDDNISManage.test("tc-3013");
		OrganizeDIDDNISManage.test("tc-3012");
		OrganizeDIDDNISManage.test("tc-3011");
		OrganizeDIDDNISManage.test("tc-3010");
		OrganizeDIDDNISManage.test("tc-3000");
		OrganizeDIDDNISManage.test("tc-3001");
		OrganizeDIDDNISManage.test("tc-3002");

		OrganizePreNumberConversion.test("tc-2905");
		OrganizeEndPoint.test("tc-2711");
		OrganizeEndPoint.test("tc-2712");
		OrganizeEndPoint.test("tc-2713");
		OrganizeEndPoint.test("tc-2714");
		OrganizeEndPoint.test("tc-2715");
		OrganizeEndPoint.test("tc-2717");
		OrganizeEndPoint.test("tc-2718");
		OrganizeEndPoint.test("tc-2730");

		// �씪�씠�꽱�뒪 �븷�떦�닔�웾 0�쑝濡� 珥덇린�솕 �븘�슂 , �씪�씠�꽱�뒪 �궘�젣 tc-5003 異붽� �븘�슂
		ResourceTotalLicense.test("tc-5000");		
		ResourceTotalLicense.test("tc-5001");
		ResourceTotalLicense.test("tc-5002");
		
		ResourceTenantbyNode.test("tc-2400");
		ResourceTenantbyNode.test("tc-2411");  //�뀒�꼳�듃蹂� �끂�뱶 �궘�젣
		ResourceTenantbyNode.test("tc-2410");

		OrganizeIpAccess.test("tc-5100");
		OrganizeIpAccess.test("tc-5101");
		
		OrganizeDnManage.test("tc-5200");
		OrganizeDnManage.test("tc-5201");
		
		OrganizeEndPoint.test("tc-2700");
		OrganizeEndPoint.test("tc-2710");
	
		
		

		
		//********** Out bound Call Test // 9116�쑝濡� 諛쒖떊 **********
		java.util.List<String> before = null;
		java.util.List<String> after = null;
	    IEStatTenant.test("tc-0211");
	    		try{
	    			
	    		for (Map.Entry<Integer, java.util.List<String>> entity : IEStatTenant.map.entrySet()) {
	    			System.out.println("Before: " + entity.getKey() + ":" + entity.getValue().toString());
	    		}
	    		
	    		before = IEStatTenant.map.get(0);
	    	
	    		ICDeveloper telephone1 = new ICDeveloper();
	    		Map<String, String> tel_config = new HashMap<String, String>();

	    			telephone1.init();
	    			telephone1.clickMenu("AgentPage");
	    			tel_config.put("TextIpAddr1", ICDev_ip1);
	    			tel_config.put("TextIpAddr2", ICDev_ip2);
	    			tel_config.put("TextStartDn", "2002");
	    			tel_config.put("TextTenantName", "tnt");
	    			tel_config.put("TextAgentID", "btagt2");
	    			tel_config.put("TextAgentPasswd", "1");
	    			tel_config.put("TextAgentDN", "2002");
	    			tel_config.put("TextTenantName2", "tnt");
	    			tel_config.put("Media Option", "Voice");
	    			tel_config.put("TextAgtAgentID", "btagt2");
	    			tel_config.put("TextAgtTenantName", "tnt");
	    			tel_config.put("TextCallDN", "2002");
	    			tel_config.put("TextCallDestDN", "9116");
	    			telephone1.set_inputs(tel_config);
	    			//System.exit(0);
	    			Thread.sleep(5000);
	    			telephone1.clickbutton("OpenServer");
	    			Thread.sleep(5000);
	    			telephone1.clickbutton("Register");
	    			Thread.sleep(5000);
	    			telephone1.clickbutton("Login");
	    			Thread.sleep(5000);
	    			telephone1.clickbutton("SetAgentState");
	    			Thread.sleep(5000);
	    			telephone1.clickbutton("MakeCall");
	    			Thread.sleep(5000);
	    			telephone1.clickbutton("ClearCall");
	    			tel_config.clear();
		
	    IEStatTenant.test("tc-0211");
	    		for (Map.Entry<Integer, java.util.List<String>> entity : IEStatTenant.map.entrySet()) {
	    			System.out.println("After: " + entity.getKey() + ":" + entity.getValue().toString());
	    		}
	    			after = IEStatTenant.map.get(0);
		    		System.out.println("before: " + before.toString());
		    		System.out.println("after: " + after.toString());
	    	
		    		String dodexpect = "1,1,0,0,0,0,0,0,1,1";
		    		String[] split = dodexpect.split(",");
		    		for (int j = 0; j < before.size(); j++) {
		    			//int i = ;
		    			before.set(j, Integer.toString(Integer.parseInt(before.get(j)) + Integer.parseInt(split[j])));
		    		}
		    		System.out.println("expected: " + before.toString());
		    	
		    		if (before.toString().equals(after.toString())) {
		    			System.out.println("******************** DOD Test suit result: pass ********************");
		    		} else
		    			System.out.println("******************** DOD Test suit result: fail ********************");
	    		
	    //********** inbound Call Test // btagt90234304198 �쑝濡� 諛쒖떊 **********
	   	    		ICDeveloper2 telephone2 = new ICDeveloper2();
		    		Map<String, String> tel_config2 = new HashMap<String, String>();
		    		
	    			telephone2.init();
	    			telephone2.clickMenu("AgentPage");
	    			tel_config2.put("TextIpAddr1", ICDev_ip1);
	    			tel_config2.put("TextIpAddr2", ICDev_ip2);
	    			tel_config2.put("TextStartDn", "2003");
	    			tel_config2.put("TextTenantName", "tnt");
	    			tel_config2.put("TextAgentID", "btagt3");
	    			tel_config2.put("TextAgentPasswd", "1");
	    			tel_config2.put("TextAgentDN", "2003");
	    			tel_config2.put("TextTenantName2", "tnt");
	    			tel_config2.put("Media Option", "Voice");
	    			tel_config2.put("TextAgtAgentID", "btagt3");
	    			tel_config2.put("TextAgtTenantName", "tnt");
	    			tel_config2.put("TextCallDN", "2003");
	 //   			tel_config2.put("TextCallDestDN", "9116");
	    			telephone2.set_inputs(tel_config2);
	    			//System.exit(0);
	    			Thread.sleep(5000);
	    			telephone2.clickbutton("OpenServer");
	    			Thread.sleep(5000);
	    			telephone2.clickbutton("Register");
	    			Thread.sleep(5000);
	    			telephone2.clickbutton("Login");
	    			Thread.sleep(5000);
	    			telephone2.clickbutton("SetAgentState");
	    			tel_config2.clear();
	    		
		    java.util.List<String> didbefore = null;
		    java.util.List<String> didafter = null;
		    IEStatTenant.test("tc-0211");
	    	    	for (Map.Entry<Integer, java.util.List<String>> entity : IEStatTenant.map.entrySet()) {
	    	    		System.out.println("DID Before: " + entity.getKey() + ":" + entity.getValue().toString());
	    	   		}
	    	   		didbefore = IEStatTenant.map.get(0);
	    	   		
	    	   		//DID 諛쒖떊 , btagt1(2002) 濡� 90234304198 諛쒖떊
	    	   			tel_config.put("TextCallDestDN", "90234304198");
	   	    			telephone1.set_inputs(tel_config);
	   	    			Thread.sleep(1000);
	   	    			telephone1.clickbutton("MakeCall");
	   	    			Thread.sleep(5000);	    			   	    			

	   	    		// DID �닔�떊 , btagt3(2003) �쑝濡� �닔�떊
		    			telephone2.clickbutton("AnswerCall");
		    			Thread.sleep(5000);
		    			telephone2.clickbutton("ClearCall");

	    		
	   	    IEStatTenant.test("tc-0211");
	   	    		for (Map.Entry<Integer, java.util.List<String>> entity : IEStatTenant.map.entrySet()) {
	   	    			System.out.println("didafter: " + entity.getKey() + ":" + entity.getValue().toString());
	   	    		}
	   	    		didafter = IEStatTenant.map.get(0);
		   	    		System.out.println("didbefore: " + didbefore.toString());
		   	    		System.out.println("didafter: " + didafter.toString());
	    	    	
	    	    		String didexpect = "1,1,0,1,1,0,0,0,2,2";
		   	    		String[] didsplit = didexpect.split(",");
	   	    		for (int j = 0; j < didbefore.size(); j++) {
    	    			//int i = ;
	   	    			didbefore.set(j, Integer.toString(Integer.parseInt(didbefore.get(j)) + Integer.parseInt(didsplit[j])));
	   	    		}
	    	   			System.out.println("expected: " + didbefore.toString());
	    	    	
	    	   		if (didbefore.toString().equals(didafter.toString())) {
	        			System.out.println("******************** DID Test suit result: pass ********************");
	   	    		} else
	   	    			System.out.println("******************** DID Test suit result: fail ********************");

	    		} catch (Exception e) {
	    		    
	    		}
*/
	}

	
	public void printResultsToConsole() {
		str_tcResult retValue = new str_tcResult();
		System.out.println ("result size :" + results.resultList.size());
		Iterator<str_tcResult> iterator = results.resultList.iterator();
		while(iterator.hasNext()) {
			retValue = iterator.next();
			System.out.println (retValue.id + ":" + retValue.result + ":" + retValue.inputValues);
		}
	}
	
	public boolean comp(Map<Integer, java.util.List<String>> v1, Map<Integer, java.util.List<String>> v2, int[] diff) throws InterruptedException {
	    try {
		java.util.List<String> L1 = new ArrayList<>();
		java.util.List<String> L2 = new ArrayList<>();
		java.util.List<String> L3 = new ArrayList<>();
		System.out.println("v1 size: " + v1.size());
		System.out.println("v2 size: " + v2.size());
		System.out.println("L3 size: " + L3.size());
		if (v1.isEmpty()) {
		    System.out.println("v1 is Empty");
		    for (int i = 0; i < v2.get(0).size(); i++) {
			L3.add("0");
		    }
		    v1.put(0, L3);
		 //   L1.clear();
		}
		System.out.println("PREV: " + v1.get(0).toString());
		System.out.println("POST: " + v2.get(0).toString());
		System.out.println("DIFF: " + Arrays.toString(diff));
		for (int i = 0; i < diff.length; i++) {
		    //System.out.println("CALC: " + v1.get(i) + ":" + diff[i] + ":" + v2.get(i));
		    if (diff[i] != -1) {
			L1.add(Integer.toString((Integer.parseInt(v1.get(0).get(i)) + diff[i])));
			L2.add(v2.get(0).get(i));
		    }
		}
		System.out.println("DIFF: " + L1.toString());
		
		if (!L2.toString().equals(L1.toString())) {
		    return false;
		}
	    } catch (Exception e) {
		System.out.println(e);
		return false;
	    }
	    return true;
	    
	}
}
