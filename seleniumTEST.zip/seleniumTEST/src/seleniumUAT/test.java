package seleniumUAT;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import automation.common;

public class test extends testSetup {
	private static String ID = "test";
	private static String PW = "test1234!!";
	private static common commands = new common();
	private static resultJiraReport jiraReport = new resultJiraReport();

	
	public test(String tc) throws InterruptedException {
		//System.out.println ("Login Test");
		boolean result = false;
		boolean logout = false;
		String testID = null;
		
		try {
			if (tc == "tc-0001" || tc == null) {
				testID = "tc-0001";
				if (tc != null) result = test(ID, PW, false);
				else result = test (ID, PW, true);
				if (!result) results.add(testID, result, "愿�由ъ옄 怨꾩젙�쑝濡� 濡쒓렇�씤 �떎�뙣 " + ID + "/" + PW, null);
				else results.add(testID, result, ID + "/" + PW, null);
				Thread.sleep(1000);
			}
			
		} catch (Exception e) {
			logger.error(e);
		}
		//if (!testResult) return false;
		//else return true;
	}
	
	public boolean test(String id, String pw, boolean logout) {
		try {
			driver.get("http://oasis1418.cafe24.com");
			
			driver.findElement(By.xpath("//*[@id=\"header\"]/div[1]/div/div[2]/a[1]")).click();
			Thread.sleep(1000);
			java.util.List<WebElement> xpathid = driver.findElements(By.xpath("//*[@id=\"userSabunOrg\"]"));
						
			if (1 == xpathid.size()) {
				//[SWAT v2.3.0 b1]ID,PW change html id : userSabunOrg, plainPwOrg
				driver.findElement(By.xpath("//*[@id=\"userSabunOrg\"]")).clear();
				driver.findElement(By.xpath("//*[@id=\"userSabunOrg\"]")).sendKeys(id);
				driver.findElement(By.id("plainPwOrg")).clear();
				driver.findElement(By.id("plainPwOrg")).sendKeys(pw);
				Thread.sleep(1000);
				driver.findElement(By.className("btn_login")).click();
				Thread.sleep(2000);

			}
			
			if (0 == xpathid.size()) {
				//[SWAT v2.3.0 b1]ID,PW change html id : userSabunOrg, plainPwOrg
				driver.findElement(By.xpath("//*[@id=\"userSabun\"]")).clear();
				driver.findElement(By.xpath("//*[@id=\"userSabun\"]")).sendKeys(id);
				driver.findElement(By.id("plainPw")).clear();
				driver.findElement(By.id("plainPw")).sendKeys(pw);
				Thread.sleep(1000);
				driver.findElement(By.className("btn_login")).click();
				Thread.sleep(2000);	
			}
			
			if (logout) {
				try {
					driver.findElement(By.xpath("//*[@id=\"head\"]/div[3]/div[2]/ul/li[3]/div/a/div")).click();
				} catch (Exception e) {
					try {
						driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/a/span/span")).click();
					} catch (Exception e2) {
						logger.error(e2);
						ErrRsn = "濡쒓렇�씤 �떎�뙣 �썑 �떎�뙣 �븣由쇱갹�씠 �굹���굹吏� �븡�쓬";
						return false;
					}
					ErrRsn = "濡쒓렇�씤 �꽦怨� �썑 �럹�씠吏� 濡쒕뵫 �떎�뙣";
					logger.error(e);
					return false;					
				}
			} else {
				WebElement msg = null;
				//System.out.println ("Login failed");
				try {
					System.out.println ("Finding message window");
					driver.findElement(By.xpath("/html/body/div[2]"));
					//driver.wait();
					//driver.findElement(By.xpath("//*[@class='panel window messager-window']"));
					System.out.println ("Found message window");
					try {
						if (driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/table/tbody/tr[2]/td/textarea")).getText().contains("�씪移섑븯吏� �븡�뒿�땲�떎")) {
							driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/a/span")).click();
						}
					} catch (Exception e1) {
						
					}
					try {
						if (driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]")).getText().contains("�씠誘� �젒�냽以묒엯�땲�떎")) {
							System.out.println ("Retry login");
							driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[4]/a[1]/span")).click();
						}
					} catch (Exception e) {
						
					}
				} catch (Exception e) {
					System.out.println ("No message window popup");
				}
			}
			Thread.sleep(1000);
			
		} catch (Exception e) {
			ErrRsn = "濡쒓렇�씤 �럹�씠吏� �뿉�윭 諛쒖깮";
			logger.error(e);
			return false;
		}
		return true;
	}
}
