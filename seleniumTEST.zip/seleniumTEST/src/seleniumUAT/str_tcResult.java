package seleniumUAT;

public class str_tcResult {
	String id;
	boolean result;
	String inputValues;
	String screenshot_file_path;
}
