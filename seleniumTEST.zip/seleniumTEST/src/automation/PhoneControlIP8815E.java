package automation;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import automation.common;
import seleniumUAT.errorReason;
import seleniumUAT.testResults;
import seleniumUAT.testSetup;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.security.UserAndPassword;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;

public class PhoneControlIP8815E extends testSetup {
	static WebDriver driver;
	private String url = "http://private:lip@100.100.106.228:8000/web_kor/home.asp";

    public static Map<Integer, java.util.List<String>> map = new HashMap<Integer, java.util.List<String>>();
	private static errorReason errReason = new errorReason();
	private static Map<String, String> searchConditions = new HashMap<String, String>();
	private static Map<String, String> menu_map = new LinkedHashMap<String, String>();
	private static common commands = new common();
	public String retString = null;
	public boolean result = false;
	
	// 怨꾩젙 �젙蹂�
	private static String ID = "private";
	private static String PW = "lip";
	public static List errcodeinfo = new ArrayList();
	
	//Excel import
	
	private static List sheetlist = new ArrayList(); 
	//private static List contentstypelist = new ArrayList();
	public static Map<String, String> xlslist = new LinkedHashMap<String, String>();
	public int rowcnt =0;
	public int columncnt =0;
	public int contentsColumncnt =0;
	public static List cnt = new ArrayList();
	
    ChromeOptions chromeOptions = new ChromeOptions();
	
	
	public void test() throws InterruptedException {
			System.out.println("== LGhtt IP8815E Setting Start ==");
			openPage();			
			//login();			
			getXlsContents("testdata");
	}
	
	public boolean openPage() throws InterruptedException {
		

	    chromeOptions.addArguments("--start-maximized");
	    driver = new ChromeDriver(chromeOptions);
		driver.get(url);
		
		//this.driver.InternalExecute(DriverCommand.REFRESH, null);

		Thread.sleep(3000);
		System.out.println("== Page Open ==");
	    return true;
	}
	
	public void getXlsContents(String tcSheetName) {
		try{
			System.out.println("== xls road ==");
			File src = new File("S:/TestData.xls");
			FileInputStream files = new FileInputStream(src);
			HSSFWorkbook wb = new HSSFWorkbook(files);		
			HSSFSheet sheet = wb.getSheet(tcSheetName);
			int sheetcnt = wb.getNumberOfSheets();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
			for (int i = 0 ; i < sheetcnt ; i++) {
				String sheetName = wb.getSheetName(i);
				sheetlist.add(sheetName);
			}
			
			//String contentsTypeValue = sheet.getRow(1).getCell(2).getStringCellValue();
			contentsColumncnt = sheet.getRow(1).getLastCellNum();
			//System.out.println("XLS data Type =" + contentsTypeValue);
			cnt.clear();
			for (int i=2 ; i < contentsColumncnt ; i++) {
				String contentstypelist = (sheet.getRow(1).getCell(i).getStringCellValue());
				System.out.println("[XLS] data Type list = " + contentstypelist.toString());
				//System.out.println("contens type 1 = " + contentsXlsType);
				//if (contentsXlsType.contains(contentstypelist) || contentsXlsType.size() == 0){
				if (contentstypelist != null) {
					
					rowcnt = sheet.getLastRowNum()+1;
					cnt.add(i-1);
					//System.out.println("[XLS] columnsize 1 : " +cnt);
					//columncnt = sheet.getRow(2).getLastCellNum();
					System.out.println("[XLS] rowcnt : "+ rowcnt);
					//System.out.println("column cnt : " + columncnt);
					//System.out.println("cnt 1 : " +cnt.toString());
					for (int j=2 ; j < rowcnt ; j++){
	
						String keylist = sheet.getRow(j).getCell(1).getStringCellValue();
						keylist = keylist;
						System.out.println("[XLS] key  : " + keylist);
						String valuelist = sheet.getRow(j).getCell(i).getStringCellValue();
						System.out.println("[XLS] value :  " + valuelist);
						xlslist.put(keylist+(i-1) , valuelist);
					}
				} else {
					System.out.println("[XLS] data 媛� 議댁옱�븯吏� �븡�뒿�땲�떎.");
				}
				System.out.println("[XLS] xlslist : " +xlslist);
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	
}